// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 1 : Tout coder
//
// Tel qu'indiqué dans la page Web, il faudra ... :
//
// - Rendre les boutons 🔽🔼 fonctionnels : ils permettent de réduire et
//   d'augmenter la température. (N'oubliez pas de mettre à jour le nombre
//   affiché dans la page Web)
//
// - Changer l'opacité du Ice Bro et du Fire Bro au besoin ... :
//     🧊 L'opacité du Ice Bro est de 1 si la température est sous 15 et
//        elle (l'opacité) est de 0.2 sinon.
//     🔥 L'opacité du Fire Bro est de 1 si la température est au-dessus de
//        10 et elle (l'opacité) est de 0.2 sinon.
//
// (De 11 à 14°c les deux bros devraient être opaques et dans les autres 
// situations il y en aura un des deux qui est translucide)
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

// Variables globales



// Écouteurs d'événements
function init(){



}

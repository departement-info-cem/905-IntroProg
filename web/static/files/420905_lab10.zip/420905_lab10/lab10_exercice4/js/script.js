
function init(){

    document.querySelector(".bouton1").addEventListener("click", styleCouleur);
    document.querySelector(".bouton2").addEventListener("click", styleMonochrome);

}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 1 : Compléter styleCouleur() et styleMonochrome()
//
// ⛔ Vous n'avez le droit qu'à une seule ligne de code par fonction.
// ⛔ Il est interdit d'utiliser document.querySelector...
//
// Les deux fonctions modifieront plusieurs styles de l'élément .texte.
//
// styleCouleur() :
// - Rend le texte "crimson".
// - Rend le fond "gold".
// - Rend la bordure "cornflowerblue".
// - Rend la bordure extérieure (outline) "limegreen".
//
// styleMonochrome() :
// - Rend le texte "white".
// - Rend le fond "lightgray".
// - Rend la bordure "darkgray".
// - Rend la bordure extérieure (outline) "black".
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function styleCouleur(){

    

}

function styleMonochrome(){



}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// Ne rien modifier à partir d'ici
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function styleChaotique(a, b, c, d){

    document.querySelector(".texte").style.backgroundColor = b;
    document.querySelector(".texte").style.color = d;
    document.querySelector(".texte").style.borderColor = a;
    document.querySelector(".texte").style.outlineColor = c;

}
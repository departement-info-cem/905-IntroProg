// Variables globales
let gAge = 15;

function init(){

    document.querySelector(".bouton1").addEventListener("click", meme1);
    document.querySelector(".bouton2").addEventListener("click", meme2);
    document.querySelector(".bouton3").addEventListener("click", meme3);
    
    document.querySelector(".bouton5").addEventListener("click", upAge);
    document.querySelector(".bouton4").addEventListener("click", downAge);

    document.querySelector(".bouton6").addEventListener("click", messageVoiture);
    document.querySelector(".bouton7").addEventListener("click", messageAlcool);
    document.querySelector(".bouton8").addEventListener("click", messageCannabis);

}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 1 : Améliorer le code
//
// Le code dans les fonctions meme1(), meme2() et meme3() est très répétitif...
// La seule chose qui varie, c'est la classe et la couleur utilisés.
//
// Pouvez-vous créer une nouvelle fonction avec deux paramètres qui permettra
// de remplacer TOUT le code dans meme1(), meme2() et meme3() par UNE SEULE
// ligne de code qui appelera cette nouvelle fonction ?
//
// (Commencez par copier-coller les trois lignes de code répétitives dans 
// votre nouvelle fonction, puis remplacez certains morceaux par des paramètres)
//
// ⛔ Assurez-vous que tout fonctionne bien comme initialement !
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
function meme1(){

    document.querySelector(".think").style.borderColor = "crimson";
    document.querySelector(".think").style.borderWidth = "5px";
    document.querySelector(".think").style.width = "200px";

}

function meme2(){

    document.querySelector(".mimic").style.borderColor = "gold";
    document.querySelector(".mimic").style.borderWidth = "5px";
    document.querySelector(".mimic").style.width = "200px";

}

function meme3(){

    document.querySelector(".debbie").style.borderColor = "cornflowerblue";
    document.querySelector(".debbie").style.borderWidth = "5px";
    document.querySelector(".debbie").style.width = "200px"

}

// ► Créer une nouvelle fonction ici ◄




// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 2 : Améliorer le code
//
// Le code dans les fonctions messageVoiture(), messageAlcool() et messageCannabis() 
// est très répétitif... La seule chose qui varie, c'est l'âge et les deux
// messages dans l'alerte.
//
// Pouvez-vous créer une nouvelle fonction avec trois paramètres qui permettra
// de remplacer TOUT le code dans messageVoiture(), messageAlcool() et 
// messageCannabis() par UNE SEULE ligne de code qui appelera cette nouvelle 
// fonction ?
//
// ⛔ Assurez-vous que tout fonctionne bien comme initialement !
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function messageVoiture()
{

    if(gAge >= 16){
        alert("Tu peux conduire ! 🚗");
    }
    else{
        alert("Il y a toujours l'autobus 🤔");
    }

}

function messageAlcool(){

    if(gAge >= 18){
        alert("Tu peux acheter de l'alcool ! 🍷");
    }
    else{
        alert("Hmmm la modération a si bon goût 😢");
    }

}

function messageCannabis(){

    if(gAge >= 21){
        alert("Tu peux acheter du cannabis ! 🌿");
    }
    else{
        alert("Au moins tu n'auras pas une drôle d'odeur 🙄");
    }

}

// ► Créer une nouvelle fonction ici ◄




// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// Ne pas modifier à partir d'ici
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function upAge(){
    gAge += 1;
    document.querySelector(".age").textContent = gAge;
}

function downAge(){
    gAge -= 1;
    document.querySelector(".age").textContent = gAge;
}



// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 1 : Ajouer 16 écouteurs d'événement à l'aide d'une boucle
//
// - À l'aide d'une boucle avec une variable i qui vaudra de 1 à 25 (inclus), 
//   ajoutez un écouteur d'événements qui appelle la fonction reserver() quand 
//   on clique sur les éléments .case1, .case2, .case3, ... etc. jusqu'à .case25.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function init(){

    document.querySelector(".boutonReserve").addEventListener("click", verifierReservation);
    document.querySelector(".boutonLibre").addEventListener("click", verifierLibre);

    // Ajouter du code ici

}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 2 : Créer la fonction reserver()
//
// Cette fonction doit simplement basculer la présence de la classe "reserve"
// pour l'élément cliqué.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀



// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 3 : Compléter la fonction compterTrottinettes()
//
// Le paramètre reçu par la fonction (reserveOuLibre) contiendra toujours
// true ou false.
//
// Si le paramètre contient true, on doit retourner le nombre de trottinettes
// réservées. Sinon, on doit retourner le nombre qui sont libres.
//
// Une seule boucle while et un seul if devraient suffire. N'oubliez pas que
// pour savoir si une trottinette est réservée ou non, on vérifie si elle
// possède la classe "reserve".
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function compterTrottinettes(reserveOuLibre){

    return 0; // À retirer ou remplacer

}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// ⛔ Ne pas modifier le code à partir d'ici
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function verifierReservation(){

    alert(compterTrottinettes(true) + " sont réservées.");

}

function verifierLibre(){

    alert(compterTrottinettes(false) + " sont libres.");

}
// Variables globales
let gNbMouches = 5;
let gNbPapillons = 3;

// Les écouteurs d'événements sont déjà faits.
function init(){

    document.querySelector(".mouche1").addEventListener("click", cacherMouche);
    document.querySelector(".mouche2").addEventListener("click", cacherMouche);
    document.querySelector(".mouche3").addEventListener("click", cacherMouche);
    document.querySelector(".mouche4").addEventListener("click", cacherMouche);
    document.querySelector(".mouche5").addEventListener("click", cacherMouche);
    document.querySelector(".papillon1").addEventListener("click", cacherPapillon);
    document.querySelector(".papillon2").addEventListener("click", cacherPapillon);
    document.querySelector(".papillon3").addEventListener("click", cacherPapillon);

    document.querySelector(".combienMouche").addEventListener("click", messageMouche);
    document.querySelector(".combienPapillon").addEventListener("click", messagePapillon);

    document.querySelector(".toucheQ").addEventListener("click", clavier);
    document.querySelector(".toucheW").addEventListener("click", clavier);
    document.querySelector(".toucheE").addEventListener("click", clavier);
    document.querySelector(".toucheR").addEventListener("click", clavier);
    document.querySelector(".toucheT").addEventListener("click", clavier);
    document.querySelector(".toucheY").addEventListener("click", clavier);
    document.querySelector(".toucheU").addEventListener("click", clavier);
    document.querySelector(".toucheI").addEventListener("click", clavier);
    document.querySelector(".toucheO").addEventListener("click", clavier);
    document.querySelector(".toucheP").addEventListener("click", clavier);
    document.querySelector(".toucheA").addEventListener("click", clavier);
    document.querySelector(".toucheS").addEventListener("click", clavier);
    document.querySelector(".toucheD").addEventListener("click", clavier);
    document.querySelector(".toucheF").addEventListener("click", clavier);
    document.querySelector(".toucheG").addEventListener("click", clavier);
    document.querySelector(".toucheH").addEventListener("click", clavier);
    document.querySelector(".toucheJ").addEventListener("click", clavier);
    document.querySelector(".toucheK").addEventListener("click", clavier);
    document.querySelector(".toucheL").addEventListener("click", clavier);
    document.querySelector(".toucheZ").addEventListener("click", clavier);
    document.querySelector(".toucheX").addEventListener("click", clavier);
    document.querySelector(".toucheC").addEventListener("click", clavier);
    document.querySelector(".toucheV").addEventListener("click", clavier);
    document.querySelector(".toucheB").addEventListener("click", clavier);
    document.querySelector(".toucheN").addEventListener("click", clavier);
    document.querySelector(".toucheM").addEventListener("click", clavier);
    document.querySelector(".spaceBar").addEventListener("click", clavier);

}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 1 : Compléter les fonctions cacherMouche et cacherPapillon
//
// - Cachez l'élément sur lequel on vient de cliquer. (Quel qu'il soit)
// - Mettez à jour le nombre de mouches OU de papillons restants dans la 
//   variable globale gNbMouches OU gNbPapillons. (Donc diminuer sa valeur de 1)
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function cacherMouche(event){



}

function cacherPapillon(event){



}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 2 : Créer une fonction nommée alerteRestant()
// - Cette fonction aura 2 paramètres :
//      - nombre : Qui représente un nombre d'insectes (ex : 1)
//      - nomInsecte : Qui représente le nom d'un insecte (ex : "papillon")
// 
// - Cette fonction ne fait qu'une chose : elle retpirme une chaîne de 
//   caractères avec le texte "Il reste X Y". X doit être remplacé par le 
//   paramètre nombre et Y doit être remplacé par le paramètre nomInsecte. 
//
//   Par exemple, si nombre vaut 2 et nomInsecte vaut "chenilles", le message
//   de l'alerte serait "Il reste 2 chenilles". Il faut utiliser la concaténation
//   pour construire cette phrase à l'aide des paramètres nombre et nomInsecte.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀




// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 3 : Compléter les fonctions messageMouche et messagePapillon
//
// - Le but de ces deux fonctions est d'appeler messageMouche() pour créer
//   obtenir un message qui indique le nombre de mouches ou papillons restants.
//   Ce message devra être glissé dans le contenu textuel de l'élément .texte
//
// - Chaque fonction contient donc une seule ligne de code : l'appel de la
//   fonction messageMouche.
//   La fonction messageMouche prend 2 paramètres. Pour le paramètre nombre,
//   utilisez la variable globale associé à chaque insecte. Pour le paramètre
//   nomInsecte, vous devrez écrire vous-même, dans une chaîne de caractères,
//   le mot "mouches" ou "papillons", selon la situation. 
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function messageMouche(){



}

function messagePapillon(){



}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 4 : Compléter la fonction clavier
//
// - La fonction clavier() ne fait qu'une seule chose : elle ajoute le contenu
//   textuel de l'élément cliqué À LA FIN du contenu textuel de l'élément
//   .texte. Comme toutes les lettres du clavier dans la page Web appellent
//   la fonction clavier() lorsque cliquées, ça permet de rédiger du texte
//   dans l'élément .texte à volonté.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function clavier(event){



}
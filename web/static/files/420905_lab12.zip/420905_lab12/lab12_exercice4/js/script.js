// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 1 : Tout coder
//
// ⛔ Vous n'avez le droit d'ajouter qu'une seule variable globale.
// ⛔ Vous n'avez le droit d'ajouter qu'une seule fonction. (Donc avec init(),
//    ça fera deux)
//
// Codez le fonctionnement suivant :
//
// → La première image qu'on clique obtient une bordure "gold".
// → La deuxième image qu'on clique obtient une bordure "pink".
// → La troisième image qu'on clique obtient une bordure "lightblue".
// → La quatrième fois qu'on clique sur une des images, les bordures de
// toutes les images redeviennent noires.
//
// Notez qu'on pourrait très bien cliquer sur la même image quatre fois ! Elle
// obtiendrait alors, tour à tour, toutes les couleurs de bordure possibles.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

// Variables globales



function init(){



}




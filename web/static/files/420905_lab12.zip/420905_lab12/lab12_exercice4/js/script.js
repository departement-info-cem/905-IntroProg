// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 0 : Comprendre les trois variables globales
//
// → gOiseaux est votre liste d'oeufs et d'oiseaux, simplement.
// → gAgesEnJours est l'âge (en nombre de jours) pour chaque oiseau.
// → gIndex sera un nombre / compteur modifiable avec des boutons 🔽🔼.
//
// Par exemple, au début le premier poussin a 5 jours, l'oeuf a 1 jour et le
// dernier poussin a 8 jours.
// 
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

// Variables globales
let gOiseaux = ["🐥","🥚","🐥"];
let gAgesEnJours = [5, 1, 8];
let gIndex = 0;

// Écouteurs d'événements (Il faudra les compléter plus tard)
function init(){

    // document.querySelector(".up").addEventListener("click", ...);
    // document.querySelector(".down").addEventListener("click", ...);
    // document.querySelector(".bouton1").addEventListener("click", ...);
    // document.querySelector(".bouton2").addEventListener("click", ...);
    // document.querySelector(".bouton3").addEventListener("click", ...);

}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 1 : Tout coder (rendre fonctionnels les 5 boutons, ajouter des fonctions)
//
// 💡 N'hésitez pas à appeler la fonction affichageTableaux() dans vos fonctions,
// elle sert à mettre à jour les deux tableaux affichés dans la page.
//
// 🔽🔼 Les deux boutons du compteur : 
// - Ils permettent simplement d'augmenter / diminuer la valeur de gIndex.
// - N'oubliez pas de mettre à jour le nombre affiché dans la page.
// - Attention ! gIndex doit être coincé entre 0 et le dernier index valide du
//   tableau gOiseaux. Donc si on a 5 oiseaux... la limite est 4. (Inclus)
//
// Le bouton « Ajouter 🥚 » : 
// - Il ajoute un "🥚" ayant 0 jour à notre élevage.
// - N'oubliez pas de mettre l'affichage des tableaux à jour dans la page.
//
// Le bouton « Retirer 🐥 » :
// - Ce bouton retire un oiseau / oeuf de l'élevage. Lequel ? Celui situé 
//   à l'index qui est dans la variable gIndex. Donc si gIndex vaut 1, on 
//   retire le deuxième oiseau dans le tableau. (Celui à l'index 1)
// - N'oubliez pas de supprimer son âge également ET de mettre l'affichage à jour.
// - Si la valeur de gIndex est maintenant invalide (car elle est trop grande
//   sachant que les tableaux viennent de rétrécir), appelez votre fonction qui
//   réduit sa valeur de 1.
//
// Le bouton « Attendre 1 jour ⏳ » :
// - Augmente tous les âges de 1.
// - Pour chaque âge qui atteint 3, remplacer l'🥚 par un par un 🐥.
// - Mettre à jour l'affichage des tableaux.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀




function affichageTableaux(){

    document.querySelector(".tableau1").textContent = "Oiseaux : " + gOiseaux;
    document.querySelector(".tableau2").textContent = "Âges en jour : " + gAgesEnJours;

}
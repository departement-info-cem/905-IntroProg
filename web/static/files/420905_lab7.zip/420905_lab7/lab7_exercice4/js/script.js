// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 1 : Tout coder
//
// Il y a trois boutons à rendre fonctionnels :
//
// 1 - Un bouton permet d'ajouter une feuille de papier dans l'imprimante.
// 2 - Un bouton permet de changer les cartouches d'encre et de rétablir leur 
//   capacité à 100%.
//
// (Pour ces deux premiers boutons, n'oubliez pas de mettre à jour l'affichage
// dans la page Web. N'oubliez pas le symbole % pour l'encre)
// 
// 3 - Un bouton pour imprimer. C'est le plus complexe, voici le comportement
//     de l'imprimante selon la situation :
//
// → Il reste 0 feuille : 
//      • Pas d'impression  
//      • Message dans la console "Veuillez ajouter du papier !! Et avec le bon format SVP ! 😠📃"
//
// → Il reste 20% ou moins d'encre :
//      • Pas d'impression
//      • Message dans la console "Veuillez changer les cartouches !! Elles sont VIDES ! 😠🎨"
//
// → Au moins une feuille et au moins 40% d'encre :
//      • On imprime !
//
// → Au moins une feille et au moins 20% d'encre :
//      • On imprime !
//      • Message dans la console : "Attention les cartouches sont faibles !! 😠🎨"
//
// ❌ Dans tous les cas, si l'impression est annulée :
//     • On crée l'alerte "Impression ANNULÉE 🚔🤬"
//
// ✅ Dans tous les cas, si l'impression fonctionne :
//     • On affiche dans la console "Page imprimée !"
//     • On diminue le % d'encre de 5 et on met à jour l'affichage.
//     • On diminue le nombre de feuille de 1 et on met à jour l'affichage.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

// Variables globales
gNbFeuilles = 5;
gPourcentageEncre = 80;


function init(){



}

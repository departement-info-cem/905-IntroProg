// -~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-
// TODO 1 : Bogues simples 😇
// - Les boutons Texte bleu, Texte rouge et Texte vert fonctionnent mal.
// - Ils sont censés changer la couleur du texte dans la boîte en-dessous.
//
// Corrigez les bugs.
// -~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-

function init(){
    document.queryselector(".bleu").addEventListener("click", texteBleu);
    document.querySelector(".rouge").addEventListener("click", texteRouge);
    document.querySelector(".vert").addEventListener("click", texteVert);
}

function texteBleu(){
    document.querySelector(".texte").style.color = "blue";
}

function texteRouge(){
    document.querySelector("texte").color = "red";
}

function texteVert(){
    document.querySelector(".vert").style.color = "green";
}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
//                            Variables globales
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

let gMotTendu = null; // Mot à deviner
let gNbErreurs = 0; // Nombre d'erreurs commises depuis le début de la manche
let gNbLettresRestantes = 0; // Nombre de lettres restantes à deviner

// Classe pour chacune des 9 <img> qui représentent le bonhomme tendu
let gMorceauxBonhomme =
    ["tete", "corps", "brasGauche", "brasDroit", "jambeGauche",
    "jambeDroite", "oeilGauche", "oeilDroit", "bouche"]; 

// Ensemble de mots tendus possibles pour le jeu
let gMotsPossibles =
    ["pneu", "chat", "pied", "sang", "rage", "oeil", "paon", "lune", "ciel",
        "porc", "corps", "chien", "matin", "coeur", "train", "tyran", "poire",
        "melon", "terre", "carte", "table", "bijou", "nappe", "maison", "bateau",
        "soleil", "tomate", "rotule", "oiseau", "banane", "citron", "viande",
        "savane", "kimono", "klaxon", "kraken", "armure", "agonie", "agneau",
        "banque", "tennis", "beigne", "beurre", "bougie", "cabine", "cactus",
        "castor", "disque", "donjon", "dragon", "empire", "emploi", "escroc",
        "flamme", "fourmi", "grotte", "indice", "jumeau", "jungle", "langue",
        "lavabo", "masque", "ordure", "phobie", "pierre", "pioche", "phrase",
        "tympan", "vapeur", "valise", "viking", "voisin", "whisky", "yaourt",
        "zigzag", "zombie", "gingembre", "printemps", "automne", "hiver",
        "promesse", "fantaisie", "horloge", "promenade", "ville", "pantoufle",
        "octogone", "abeille", "miel", "ouragan", "omelette", "apocalypse",
        "spectacle", "avalanche", "astronomie", "psychologie", "histoire",
        "saturne", "mars", "couteau", "arbre", "perroquet", "traumatisme",
        "diamant", "hippopotame", "quincaillerie", "trampoline", "cylindre",
        "internet", "catastrophe", "tsunami", "garderie", "xylophone"];

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
//                              Initialisation
//
// Vous aurez à ajouter des écouteurs d'événements très simples éventuellement.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function init() {

}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
//                         Fonctions (Section guidée)
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

// Choisit un mot aléatoire parmi tous les mots du jeu pour la prochaine partie.
function choisirMotTendu() {



}

// Affiche toutes les lettres du mot tendu dans la page.
function perdu() {



}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
//                         Fonctions (Section libre)
//
// N'oubliez pas de commenter chacune de vos fonctions. (Français évalué)
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function tenterLettre(event) {

    // Ceci permet de mettre fin à la fonction si la touche appuyée n'est pas une lettre.
    if (!event.key.match("^[a-z]")) {
        event.preventDefault();
        return;
    }

    // À compléter

}




// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
//                     Code déjà complété (Peut être édité)
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

// Tente de placer la lettre reçue en paramètre dans la page. 
// Retourne true si la lettre était valide et false sinon.
function placerLettre(lettre) {

    let contientLettre = false;
    let elements = document.querySelectorAll(".lettreTendue");

    for (let i = 0; i < gMotTendu.length; i += 1) {

        // Une lettre correspondante a été trouvée !
        if (gMotTendu.charAt(i) == lettre) {
            elements[i].textContent = lettre;
            contientLettre = true;
        }

    }

    return contientLettre;

}

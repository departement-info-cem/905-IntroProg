// Variables globales
let gPrixChambre = 150;
let gRituelDemoniaque = false;
let gCouleurTapisserie = "turquoise";

// Écouteurs d'événements déjà déclarés ! (Rien à ajouter)
function init() {

    boutonsVariables();
    document.querySelector(".carmen").addEventListener("click", interetCarmen);
    document.querySelector(".omar").addEventListener("click", interetOmar);

}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 1 : Compléter les fonctions interetCarmen() et interetOmar().
//
// Ces fonctions modifient le texte dans le bas de le page. Elles indiquent si
// Omar et Carmen sont intéressés par l'hôtel quand on clique sur leur bouton.
//
// Carmen :
// - Le texte sera "Carmen est intéressée" si l'hôtel organise des rituels
//   démoniaques ET que le prix d'une chambre est inférieur à 180.
// - Le texte sera "Carmen est un peu intéressée" si l'hôtel organise des
//   rituels démoniaques, même si le prix est de 180 ou plus.
// - Le texte sera "Carmen n'est pas intéressée" sinon.
//
// Omar :
// - Le texte sera "Omar est intéressé" si la tapisserie de l'hôtel est de
//   couleur "lilas" OU que le prix d'une chambre est inférieur ou égal à 230.
// - Le texte sera "Omar n'est pas intéressé" sinon.
//
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
function interetCarmen() {


    
}

function interetOmar() {



}


// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// NE PAS TOUCHER AU CODE À PARTIR D'ICI
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function boutonsVariables() {

    document.querySelector("#bouton1").addEventListener("click", reduirePrixChambre);
    document.querySelector("#bouton2").addEventListener("click", augmenterPrixChambre);
    document.querySelector("#bouton3").addEventListener("click", toggleRituelDemoniaque);
    document.querySelector("#bouton4").addEventListener("click", changerCouleurTapisserie);

}

function reduirePrixChambre() {

    gPrixChambre -= 50;
    document.querySelector("#prixChambre").textContent = gPrixChambre;

}

function augmenterPrixChambre() {

    gPrixChambre += 50;
    document.querySelector("#prixChambre").textContent = gPrixChambre;

}

function toggleRituelDemoniaque() {

    gRituelDemoniaque = !gRituelDemoniaque;
    document.querySelector("#rituelDemoniaque").textContent = gRituelDemoniaque;

}

function changerCouleurTapisserie() {

    gCouleurTapisserie = gCouleurTapisserie == "turquoise" ? "lilas" :
        gCouleurTapisserie == "lilas" ? "kaki" : "turquoise";
    document.querySelector("#couleurTapisserie").textContent = gCouleurTapisserie;

}
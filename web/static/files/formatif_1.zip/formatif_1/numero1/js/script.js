
// Variables globales
let gFavoriChoisi = false;

function init(){

    document.querySelector(".mario").addEventListener("click", bordureDore);
    document.querySelector(".luigi").addEventListener("click", bordureDore);
    document.querySelector(".wario").addEventListener("click", bordureDore);
    document.querySelector(".waluigi").addEventListener("click", bordureDore);

}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 1 : Créer la fonction bordureDore
//
// Tel qu'indiqué dans la page Web, le but est de rendre "gold" la bordure
// de l'image cliquée. Cela dit, seul le premier clic doit fonctionner. Tous
// les clics suivants ne doivent absolument rien faire.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀


function init(){

    document.querySelector(".boutonAllo").addEventListener("click", allo);
    document.querySelector(".boutonBye").addEventListener("click", bye);
    document.querySelector(".boutonAdd").addEventListener("click", add);
    document.querySelector(".boutonMul").addEventListener("click", mul);

}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 1 : Créer la fonction verifierSiAllo()
//
// Cette fonction doit recevoir une classe en paramètre. (Ex : ".bateau")
//
// Cette fonction retourne true si l'élément avec la classe reçue en paramètre
// possède un contenu textuel identique à "allo".
// La fonction retourne false sinon.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀




// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 2 : Créer la fonction multiplierOuAdditionner()
//
// Cette fonction reçoit trois paramètres :
// - Deux nombres quelconques.
// - Un booléen qui servira à déterminer si on multiplie ou divise
//
// Si le booléen reçu est true, on retourne la multiplication des deux nombres
// reçus.
// Sinon, on retourne la somme des deux nombres reçus.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀




// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// ⛔ Ne pas modifier à partir d'ici
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function allo(){
    document.querySelector(".texte").textContent = verifierSiAllo(".boutonAllo");
}

function bye(){
    document.querySelector(".texte").textContent = verifierSiAllo(".boutonBye");
}

function add(){
    document.querySelector(".texte").textContent = multiplierOuAdditionner(5, 2, false);
}

function mul(){
    document.querySelector(".texte").textContent = multiplierOuAdditionner(3, 4, true);
}
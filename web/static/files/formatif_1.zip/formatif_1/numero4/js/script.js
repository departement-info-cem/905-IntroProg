// Variables globales
let gQteAubergines = 0;
let gQtePeches = 0;

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 1 : Dans la fonction init(), il faudra ajouter un écouteur
//          d'événements pour rendre le bouton « Calculer le prix »
//          fonctionnel.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
function init(){
    
	boutonsVariables(); // Ne pas toucher à cette ligne




}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 2 : Compléter la fonction calculerPrix(), qui affiche le prix total
//          des aubergines et des pêches dans la page.
//
// - On déclare une variable locale nommée total, dans laquelle on met le 
//   prix total des deux fruits multipliés par leur quantité respective.
// - On affiche un message détaillé qui explique le prix. (Voir l'exemple ci-
//   dessous pour le format du message)
//
// Exemple : si on achète 2 aubergines et 2 pêches, le message sera ...
// "Acheter 2 aubergine(s) et 2 pêche(s) coûte 10 $"
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
function calculerPrix(){



}


// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// NE PAS TOUCHER AU CODE À PARTIR D'ICI
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function boutonsVariables(){

    document.querySelector(".bouton1").addEventListener("click", reduireQteAubergines);
    document.querySelector(".bouton2").addEventListener("click", augmenterQteAubergines);
    document.querySelector(".bouton3").addEventListener("click", reduireQtePeches);
    document.querySelector(".bouton4").addEventListener("click", augmenterQtePeches);

}

function augmenterQteAubergines(){

    gQteAubergines += 1;
    document.querySelector(".qteAubergines").textContent = gQteAubergines;

}

function reduireQteAubergines(){

    gQteAubergines = Math.max(0, gQteAubergines - 1);
    document.querySelector(".qteAubergines").textContent = gQteAubergines;

}

function augmenterQtePeches(){

    gQtePeches += 1;
    document.querySelector(".qtePeches").textContent = gQtePeches;

}

function reduireQtePeches(){

    gQtePeches = Math.max(0, gQtePeches - 1);
    document.querySelector(".qtePeches").textContent = gQtePeches;

}
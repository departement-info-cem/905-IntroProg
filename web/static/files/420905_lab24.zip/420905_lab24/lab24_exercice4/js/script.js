// Variables globales
let gCodeSecret = []; // Contiendra le code secret (ex : 2,7,0)
let gCode = [0,0,0];  // Contient les nombres affichés à l'écran, contrôlés par l'utilisateur

function init(){

    genererCodeSecret();

    // Écouteurs d'événements pour les boutons 🔼
    let ups = document.querySelectorAll(".up");

    for(let i = 0; i < ups.length; i += 1){
        ups[i].addEventListener("click", function(){ augmenter(i) });
    }

    // Écouteurs d'événements pour les boutons 🔽
    let downs = document.querySelectorAll(".down");
    
    for(let i = 0; i < downs.length; i += 1){
        downs[i].addEventListener("click", function(){ reduire(i) });
    }

    document.querySelector(".btnVerifier").addEventListener("click", verifierCode);

}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 1 : Compléter genererCodeSecret()
//
// Cette fonction est déjà appelée lors de l'ouverture de la page Web, dans
// init(). Son objectif est de remplir la variable globale gCodeSecret avec
// trois nombres entiers aléatoires entre 0 et 9.
//
// Les trois nombres aléatoires rangés dans le tableau vont correspondre au
// « code secret » à deviner par l'utilisateur.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
function genererCodeSecret(){



}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 2 : Compléter reduire() et augmenter()
//
// reduire() est déjà appelée par tous les boutons 🔽 et augmenter() par
// tous les boutons 🔼.
//
// L'objectif est simplement de pouvoir réduire et augmenter la valeur des
// trois compteurs. Attention ! Les compteurs doivent rester coincés entre
// 0 et 9. (inclus)
//
// La variable globale gCode sert à garder en mémoire à quel nombre est rendu
// chaque compteur. Il faudra mettre à jour le bon nombre dans le tableau.
//
// Les deux fonctions reçoivent un paramètre nommé index qui contient le 
// nombre 0, 1 ou 2. 0 veut dire le premier compteur (gauche), 1 veut dire
// le deuxième compteur (milieu) et 2 veut dire le dernier compteur (droite).
//
// ⛔ Interdit d'utiliser un bloc conditionnel (if, else, else if, switch et
// condition ternaire.) 
// Utilisez les fonctions mathématiques pour bloquer les compteurs entre 0 et 9.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
function reduire(index){



}

function augmenter(index){



}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// Cette fonction vous est déjà fournie ! Elle est appelée quand on appuie
// sur le bouton « Vérifier » 
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

// Vérifie si le code rentré par l'utilisateur est identique au code secret et crée une alerte.
function verifierCode(){

    for(let i = 0; i < gCode.length; i += 1){

        if(gCodeSecret[i] != gCode[i]){

            alert("Code erroné ! ❌");
            return;

        }

    }

    alert("Code valide ! ✅");

}
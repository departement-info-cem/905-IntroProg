
// Écouteurs d'événements
function init(){

    document.addEventListener("keydown", toucheClavier);
    document.querySelector(".bouton1").addEventListener("click", nbDeSymboles);
    document.querySelector(".bouton2").addEventListener("click", retirerDernierSymbole);
    document.querySelector(".bouton3").addEventListener("click", oeufDevientPoule);
    document.querySelector(".bouton4").addEventListener("click", m_deviennent_b);
    document.querySelector(".bouton5").addEventListener("click", minuscules);
    document.querySelector(".bouton6").addEventListener("click", majuscules);
    document.querySelector(".bouton7").addEventListener("click", dernierSymbole);
    document.querySelector(".bouton8").addEventListener("click", multiple);

}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 1 : Compléter plusieurs fonctions simples
//
// Pour toutes les fonctions suivantes, il faudra récupérer le texte dans
// l'élément .texte, le modifier et mettre à jour la page.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

// Lancez une alerte avec le message "Il y a X caractères." où X sera 
// remplacé avec la taille (longueur) du texte.
function nbDeSymboles(){



}

// Retirez le dernier caractère affiché dans le texte à l'aide de la
// fonction substring().
function retirerDernierSymbole(){



}

// Remplacez la première occurence de "oeuf" dans le texte par "poule" dans
// le texte affiché. (Seulement la première !)
function oeufDevientPoule(){



}

// Remplacez TOUTES les occurences de "m" par "b" dans le texte affiché.
function m_deviennent_b(){



}

// Rendez le texte tout en minuscules.
function minuscules(){



}

// Rendez le texte tout en majuscules.
function majuscules(){



}


// À l'aide de la fonction charAt(), affichez le dernier caractère du texte
// dans une alerte.
function dernierSymbole(){



}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 2 : Compléter multiple()
//
// - Faites plusieurs opérations sur le texte :
//      -> Mettez tout en majuscules.
//      -> Remplacez toutes les occurences de "6" par "7".
//      -> Retirez le premier symbole du texte.
// - De plus, après ces modifications, comptez le nombre de "F" dans le texte
//   et affichez le total dans une alerte.
//
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
function multiple(){



}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// Ne pas modifier le code à partir d'ici
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function toucheClavier(e){
    if(e.key == " " || e.key == "'"){
        e.preventDefault();
    }
    if(e.key.length == 1){
        document.querySelector(".texte").textContent += e.key;
    }
    if(e.key == "Backspace"){
        document.querySelector(".texte").textContent = 
        document.querySelector(".texte").textContent.substring(0, 
            document.querySelector(".texte").textContent.length - 1)
    } 
    if(e.key == "Enter"){
        document.querySelector(".texte").textContent = "";
    }
}
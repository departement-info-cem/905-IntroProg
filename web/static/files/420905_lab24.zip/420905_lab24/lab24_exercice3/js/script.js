// Variables globales

let gCodeSecret = [];      // Contiendra le code secret (ex : 1,3,2,1,2,1)
let gCode = [1,1,1,1,1,1]; // Contient les nombres affichés à l'écran

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 1 : Créer des écouteurs d'événements avec paramètre
//
// (Faites ce TODO après le TODO 2 pour mieux comprendre)
//
// Il y a déjà du code qui parcourir tous les éléments avec la classe .up et
// avec la classe .down
//
// - Ajoutez simplement des écouteurs d'événements pour que chacun des boutons
//   🔽🔼 appellent la fonction augmenter() ou reduire() lorsqu'on clique
//   dessus. Le premier bouton utilise l'index 0, le deuxième utilise
//   l'index 1, etc. jusqu'à 5. (Comme les tableaux sont de taille 6)
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function init(){

    genererCodeSecret();

    let ups = document.querySelectorAll(".up");

    for(let i = 0; i < ups.length; i += 1){



    }

    let downs = document.querySelectorAll(".down");
    
    for(let i = 0; i < downs.length; i += 1){


        
    }

    document.querySelector(".btnVerifier").addEventListener("click", verifierCode);

}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 2 : Compléter réduire() et augmenter()
//
// ⛔ Ces deux fonctions sont courtes (2 lignes de code minimum), mais complexes
// à bien comprendre. Lisez bien.
//
// D'abord, vérifiez le HTML : il y a six boutons 🔽 et six boutons 🔼. Ils
// serviront à changer chacun des six nombres dans la page. Toutefois, on veut
// juste pouvoir naviguer de 1 à 3. (Impossible de descendre à 0 ou de monter à 4)
//
// Les six chiffres dans la page doivent également être stockés dans la variable
// globale gCode. (Le premier chiffre est à l'index 0, le deuxième à l'index 1,
// etc jusqu'à l'index 5) Remarquez que tous les nombres commencent à 1.
//
// Bref, voici ce qu'il faut coder :
//
// - Augmenter ou diminuer de 1 le nombre à l'index reçu en paramètre dans gCode.
// - Mettez à jour l'affichage de ce nombre dans la page.
//
// Exemple : disons qu'on appelle reduire(2), gCode pourrait passer de [1,3,2,3,3,1]
// à [1,3,1,3,3,1], puis on va changer le contenu textuel du troisième élément
// avec la classe .code pour y afficher le nombre 1 plutôt que le nombre 2.
//
// N'oubliez pas d'empêcher les nombres de descendre sous 1 ou d'augmenter au-dessus
// de 3 ! Un if devrait suffire pour ça.
//
// ⭐ Défi : Utilisez Math.max() ou Math.min() plutôt qu'un if pour empêcher
// les nombres de descendre à 0 et de monter à 4.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function reduire(index){



}

function augmenter(index){



}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 3 : Compléter genereCodeSecret()
//
// Cette fonction est déjà appelée dans init(), quand la page Web charge.
//
// Ajoutez (avec push), dans gCodeSecret, six nombres ENTIERS aléatoires 
// parmi 1, 2 ou 3.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function genererCodeSecret(){



}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 4 : Compléter vérifierCode()
//
// On doit simplement créer l'alerte "Code valide ! ✅" si gCode et gCodeSecret
// sont identiques et l'alerte "Code erroné ! ❌" sinon.
//
// Rappel : impossible de vérifier en faisant gCode == gCodeSecret. Pour des
// tableaux il faut vérifier chaque valeur, une à la fois.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function verifierCode(){



}
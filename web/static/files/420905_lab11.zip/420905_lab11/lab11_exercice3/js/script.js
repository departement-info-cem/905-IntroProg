// Variables globales
let gNbEtoiles = 0;
let gNbPlanetes = 0;

// Écouteurs d'événements (Rien à ajouter)
function init(){
    document.addEventListener("keydown", changerDirection);
    document.querySelector(".jouer").addEventListener("click", jouer);
}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 1 : Créer la fonction calculerScore()
//
// - La fonction est déjà appelée un peu plus bas. Vous devrez analyser comment
//   elle est appelée pour bien la créer.
//
// - Elle doit simplement retourner le score du joueur : 3 points par étoile,
//   moins 5 points par planète, mais minimum 0 (pas de score négatif)
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀






// ⛔ Pas le droit de modifier cette fonction, mais vous devez l'analyser !
function afficherScore(){
    let score = calculerScore(gNbEtoiles, gNbPlanetes);
    document.querySelector(".score").textContent = `Score : ${score}`;
}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// Ne pas toucher au code à partir d'ici
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

let gDirection = "up";
let gVitesse = 0.5;
let gEtoilesRestantes = 15;
let gElementCollision;
let gPlanificateur;

function changerDirection(evenement){
    let touche = evenement.key;
    evenement.preventDefault();
    if(touche == "ArrowUp"){
        gDirection = "up";
    }
    else if(touche == "ArrowDown"){
        gDirection = "down";
    }
    else if(touche == "ArrowLeft"){
        gDirection = "left";
    }
    else if(touche == "ArrowRight"){
        gDirection = "right";
    }
}

function collision(){
    if(gElementCollision.classList.contains("planete")){
        retirerEtoile();
        gNbPlanetes += 1;
    }
    else{
        gEtoilesRestantes -= 1;
        retirerEtoile();
        gNbEtoiles += 1;
    }
}

function jouer(){
    gNbEtoiles = 0;
    gNbPlanetes = 0;
    document.querySelector(".score").textContent = "";
    gVitesse = 0.5;
    gDirection = "up";
    gEtoilesRestantes = 15;
    document.querySelector(".jouer").style.display = "none";
    let f = document.querySelector("#fusee");
    f.style.left = "380px";
    f.style.top = "460px";
    f.setAttribute("src", "images/fuseeU.png");
    gPlanificateur = setInterval(animerJeu, 10);
    lancerJeu();
}

function lancerJeu(){
    let elements = document.querySelectorAll(".obstacle");
    for(let e of elements){
        let x = 0;
        let y = 0;
        do{
            x = Math.floor(Math.random() * 771);
            y = Math.floor(Math.random() * 471);
        }while(x > 330 && x < 400 && y > 350);
        e.style.display = "block";
        e.style.top = y + "px";
        e.style.left = x + "px";
    }
}

function finPartie(){
    document.querySelector(".jouer").style.display = "block";
    clearInterval(gPlanificateur);
    afficherScore();
}

function retirerEtoile(){
    gElementCollision.style.display = "none";
    gElementCollision.style.left = "-50px";
}

function animerJeu(){
    document.querySelector(".reste").textContent = gEtoilesRestantes;
    if(gEtoilesRestantes == 0){
        alert("Bravo !");
        finPartie();
    }
    gVitesse += 0.0075;
    let f = document.querySelector("#fusee");
    let x = parseFloat(f.style.left);
    let y = parseFloat(f.style.top);
    switch(gDirection){
        case "up" : f.style.top = y - gVitesse + "px"; f.setAttribute("src", "images/fuseeU.png");
            break;
        case "down" : f.style.top = y + gVitesse + "px"; f.setAttribute("src", "images/fuseeD.png");
            break;
        case "left" : f.style.left = x - gVitesse + "px"; f.setAttribute("src", "images/fuseeL.png");
            break;
        default : f.style.left = x + gVitesse + "px"; f.setAttribute("src", "images/fuseeR.png");
    }
    x = parseFloat(f.style.left);
    y = parseFloat(f.style.top);
    if(x < 0 || x > 760 || y < 0 || y > 460){
        finPartie();
        document.querySelector("#fusee").setAttribute("src", 'images/explosion.png');
    }
    let elements = document.querySelectorAll(".obstacle");
    for(let e of elements){
        let oX = parseInt(e.style.left);
        let oY = parseInt(e.style.top);
        if(x < oX + 25 && x + 35 > oX && y < oY + 25 && y + 35 > oY){
            gElementCollision = e;
            collision();
        }
    }
}

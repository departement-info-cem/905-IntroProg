
// Écouteurs d'événements déjà complétés
function init(){

    document.querySelector(".bouton1").addEventListener("click", alerteNombre);
    document.querySelector(".bouton2").addEventListener("click", calculPrix);
    document.querySelector(".bouton3").addEventListener("click", animalPrefere);

}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 1 : Compléter obtenirNombre() et alerteNombre()
//
// - La fonction obtenirNombre() doit tout simplement retourner la valeur
//   42.
//
// - Dans la fonction alerteNombre(), on lance simplement une alerte pour
//   afficher le nombre 42. Vous ne devez pas écrire 42 vous-même dans la
//   fonction alert(), vous devez appeler la fonction obtenirNombre() DANS
//   alert(), de manière à ce que la valeur 42 qui est retournée par 
//   obtenirNombre() se retrouve dans l'alerte.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
function obtenirNombre(){



}

function alerteNombre(){



}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 2 : Compléter obtenirPrix(), obtenirQuantite() et calculPrix()
//
// - Avec obtenirPrix(), retournez la valeur 3.5
// - Avec obtenirQuantite(), retournez la valeur 2
// 
// Pour calculPrix() : (Tout ça c'est juste 2 lignes de code)
// - Créez une variable locale nommée prixTotal, et stockez la multiplication
//   des valeurs retournées par obtenirPrix() et obtenirQuantite() dedans.
//   (Donc en gros prixTotal doit contenir 3.5 * 2, mais vous appelez les
//    deux fonctions en les multipliant au lieu d'écrire les nombres vous-mêmes)
// - Finalement, remplacez le contenu textuel de l'élément .texte par
//   "X pommes coûtent Y dollars.". Remplacez X par la valeur retournée par
//   obtenirQuantite() et remplacez Y par le prixTotal calculé au-dessus.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
function obtenirPrix(){



}

function obtenirQuantite(){



}

function calculPrix(){



}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 3 : Compléter obtenirAnimal() et animalPrefere()
//
// Pour obtenirAnimal() :
// - À l'aide de Math.random(), retournez une des deux valeurs suivantes :
//      • Dans 50% des cas, "chien".
//      • Dans 50% des cas, "chat".
//
// Pour animalPrefere() :
// - Si la valeur retournée par obtenirAnimal() est égale à "chien", on 
//   écrit "J'adore les pitous" dans la console. Sinon, on écrit "J'adore 
//   les minous." dans la console.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
function obtenirAnimal(){



}

function animalPrefere(){



}


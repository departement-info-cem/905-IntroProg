// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 0 : Observer les variables globales présentes
//
// - Il est important de jeter un coup d'oeil aux variables globales car
//   vous devrez les utiliser à plusieurs reprises dans le projet !
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

let gCourseEnCours = false;

// Dans les trois tableaux ci-dessous, tableau[0] représente le joueur 1, tableau[1] représente le joueur 2, etc.

let gJoueurs;               // Tableau de toutes les <img> (Éléments HTML) des joueurs.
let gOmbres;                // Tableau de toutes les <img> (Éléments HTML) des ombres des joueurs. (Cercle gris sous chaque joueur)
let gTours = [0,0,0,0];     // Combien de tours chaque joueur a complété

let gPlanificateurDecompte; // Planificateur pour le décompte avant le départ
let gPlanificateurChrono;   // Planificateur pour le chronomètre durant la course

let gVitesseMaximale = 5;   // Vitesse maximale en pixels par seconde. 5 est recommandé. Ne pas mettre plus de 6. 😠
let gDifficulte = 1;        // 1 -> Facile, 2 -> Normal, 3 -> Difficile
let gDecompte = 3;          // Nombre de secondes avant le début de la course

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 1 : Remplir deux tableaux et ajouter des écouteurs d'événements
//
// - D'abord, remplissez, dans la fonction init(), la variable gJoueurs avec
//   les 4 images des joueurs. (Elles ont une classe commune !)
// - Remplissez aussi, juste après, la variable gOmbres avec les 4 images
//   des ombres des joueurs.
//
// - Vous aurez à ajouter des écouteurs d'événements en faisant le TODO 7.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

// Écouteurs d'événements et initialisation de variables globales
function init(){

    // À compléter



    // Autres écouteurs événements et planificateurs (Ne pas toucher)
    document.querySelector(".go").addEventListener("click", lancerCourse);
    planificateurs();
}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 2 : Créer la fonction cacherOuAfficherElements()
//
// - Cette fonction possède 2 paramètres :
//      → classe : Une chaîne de caractères qui représente une classe, comme
//        ".joueur" ou ".ombre" par exemple.
//      → valeurDisplay : Une chaîne de caractères qui contient "block" ou
//        "none".
//
// - Cette fonction rend visibles ou invisibles TOUS les éléments HTML avec
//   la classe fournie en paramètre. C'est la valeur du paramètre 
//   valeurDisplay qui est utilisée pour rendre visibles ou invisibles les
//   éléments.
//
// - Exemple d'usage : si j'appelle cacherOuAfficherElements(".ombre", "none"),
//   tous les éléments HTML avec la classe .ombre seront cachés.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

// ↓ Créer la fonction cacherOuAfficherElements() ci-dessous ↓



// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 3 : Compléter la fonction preparerCourse()
//
// - Cette fonction a 1 paramètre :
//      → nombreDeJoueurs : Contient un nombre qui représente la quantité de
//        joueurs qui participeront à la course. (Donc un nombre de 1 à 4)
//
// Cette fonction fait plusieurs actions pour préparer la course :
//
// - En appelant trois fois la fonction cacherOuAfficherElements(), assurez-
//   vous de cacher les éléments avec .preparation, d'afficher les éléments
//   avec .joueur et d'afficher les éléments avec .ombre
//
// - En fonction du nombre de joueurs reçu en paramètre, afficher les éléments
//   .controls0, .controls1, .controls2 et .controls3. (Par exemple, s'il y
//   a deux joueurs, on rend seulement visible .controls0 et .controls1 !)
//   Vous êtes obligés d'utiliser une boucle pour faire ceci.
//
// - Finalement, appelez une fonction qui permettra de placer les joueurs dans
//   la course. (Fouillez en bas de ce fichier pour trouver la fonction à
//   appeler !) Vérifiez si la fonction a besoin de paramètres pour être appelée.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function preparerCourse(nombreDeJoueurs){



}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 4 : Compléter la fonction decompte()
//
// Notez que la fonction decompte() sera appelée environ chaque seconde une fois
// la course lancée. Son but sera d'afficher le décompte 3, 2, 1, GO !
// Le planificateur à intervalles est déjà créé ailleurs, contentez-vous de
// réaliser les actions ci-dessous :
//
// - Dans tous les cas, on commence par réduire la valeur du décompte de 1.
//   (Voir variables globales !)
//
// - Ensuite, selon le nombre de secondes restantes, on va faire une opération
//   différente ... :
//      • 3, 2 ou 1 seconde : Simplement afficher le nombre de secondes restantes
//        dans le contenu textuel de .decompte.
//      • 0 seconde : On affiche "Go !" à la place.
//      • -1 seconde : On met fin au planificateur à intervalles du décompte
//             et on cache le décompte. De plus, on modifie une variable
//             globale pour indiquer que la course est en cours. Finalement,
//             on crée un planificateur à intervalles qui appelle augmenterChrono()
//             chaque seconde et on le range dans la bonne variable globale.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function decompte(){



}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 5 : Compléter la fonction courseEstElleFinie()
// 
// Cette fonction possède 1 paramètre :
//      → nbTours : C'est le nombre de tours à compléter pour la course actuelle
//        (Donc 3, 4, 5 ou 9 selon la course)
//
// Cette fonction doit absolument retourner la valeur true ou false.
// ⛔ Vous êtes obligés d'utiliser une boucle.
//
// - Si tous les joueurs ont fini la course, on retourne true.
// - Si au moins un joueur n'a pas fini la course, on retourne donc false.
//
// Par exemple, disons que gTours contient [4, 4, 3, 4] et que nbTours vaut 4...
// il faut retourner false car on remarque qu'un joueur n'a pas fini la course !
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function courseEstElleFinie(nbTours){

    

}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 6 : Compléter la fonction activationItems()
//
// Cette fonction permettra aux joueurs d'activer leur item lorsqu'ils en
// ont un !
//
// - Sachant que cette fonction est appelée lors d'un événement clavier 
//   (l'événement clavier en question a déjà été créé ailleurs !), le but
//   est d'appeler la fonction activerItemJoueur(). Le paramètre à envoyer
//   à la fonction activerItemJoueur sera un nombre de 0 à 3, selon le joueur
//   qui a appuyé sur sa touche item. Par exemple, si la touche "ArrowDown"
//   a été appuyée, on sait que c'est le Joueur 1 (personnage rouge) qui a
//   activé son item et donc on doit utiliser activerItemJoueur(0).
//   Vérifiez les contrôles pour trouver quelle touche correspond à quel joueur.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function activationItems(event){



}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 7 : Compléter la fonction changerDifficulte()
//
// En résumé, cette fonction permettra de choisir la difficulté du jeu.
//
// - Vous devrez ajouter deux écouteurs d'événements dans init() pour que les
//   deux flèches ◄ ► sur le bouton « Facile » appellent la fonction ci-dessous.
//
// - Essayez d'écrire le moins souvent document.querySelector() dans cette
//   fonction. (Trois fois au MAXIMUM, bien que deux soit possible aussi)
//
// ⭐ Il y a des indications supplémentaires dans l'énoncé Web ! ⭐
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function changerDifficulte(event){



}

// ⭐⭐ Bravo ! Vous avez fini la partie 1 ! Vous avez presque terminé ! ⭐⭐

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// Ne pas modifier le code à partir d'ici
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

// Active l'item d'un joueur dont l'index dans le tableau gJoueurs est 0, 1, 2 ou 3
// (Donc si le paramètre num vaut 0, le premier joueur active son item...)
function activerItemJoueur(num){
    if(num <= 4 - 1){
        zPlayers[num].activateItem();
    }
}

// Place les joueurs derrière la ligne d'arrivée pour le début de la course.
// Le paramètre n doit correspondre au nombre de joueurs qui participent.
function placerJoueurs(n){
    zNbJoueurs = n;
    zChronometre = 0;
    document.querySelector("#chrono").textContent = "00:00";
    document.querySelector("#scores").style.display = "none";
    document.querySelector(".go").style.display="block";
    document.querySelector("#stop").style.display="block";
    document.querySelector(".difficulte").style.display="none";
    document.querySelector("#positionsMoyennes").style.display = "none";
    zMeteorDistance = 0;
    createPlayers(n);
    for(let index = 0; index < 4; index += 1){
        zAffichageTours[index].style.display = "block";
        let point = zRaces[zRaceChoice].spawns[index];
        zPlayers[index].place(zRaces[zRaceChoice].spawnRotation, point.x, point.y);
        zPlayers[index].speed = 0;
        zVitesseJoueurs[index] = 0;
        zPlayers[index].score = 0;
        gTours[index] = 0;
        zAffichageTourJoueurs[index].textContent = " 0/"+ zRaces[zRaceChoice].nbTours;
        zPlayers[index].hasCrashed = false;
        zPlayers[index].checkpointMarker = 0;
    }
    zPlaces = [0,0,0,0];
    let boxes = zRaces[zRaceChoice].boxes;
    for(let b of boxes){
        b.display();
    }
}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
//                               📦 DLCs 📦
//
// - ATTENTION : Vous ne devez pas faire tous les DLCs ! Vous devez seulement
//   accumuler 6 points. Plus un DLC est complexe, plus il vaut de points.
//
//     → DLC A - 🏆      Get gud      🏆 : 2 points
//     (La position moyenne des personnages est affichée pour toutes les courses jouées)
//
//     → DLC B - 🌈    C'est zouli    🌈 : 2 points
//     (L'item étoile a une meilleure animation)
//
//     → DLC C - 🔫   360 no scope    🔫 : 4 points
//     (Ajout d'une animation lorsqu'un joueur fait un 360°)
//
//     → DLC D - 😃  Supplice visuel  😃 : 4 points
//     (Nouvel item qui cache les joueurs avec des émojis géants)
//
//     → DLC E - 🔍    Konami Code    🔍 : 6 points
//     (Entrer un code secret sur le clavier fait apparaître une 5e course)
//
//     → DLC F - 🥊   Hey tasse-toé    🥊 : 6 points
//     (Nouvel item qui repousse les joueurs à proximité)
//
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

// █████████████████████████████████████████████████████████████████████████
// 🏆 DLC A : Get gud 🏆
// █████████████████████████████████████████████████████████████████████████

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO A-1 : Mettre gPositionMoyenneAffichee à true. Ça activera l'affichage
// des positions moyennes.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

let gPositionMoyenneAffichee = false;
let gSommePositions = [0,0,0,0]; // Contient la somme des positions pour chaque personnage.
let gNbCoursesJouees = 0; // Nombre de courses jouées

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO A-2 : Compléter calculerPositionMoyenne()
//
// ⭐ Il y a des indices supplémentaires dans l'énoncé Web ⭐
//
// Pour chacun des quatre éléments avec la classe .positionMoyenne,
// afficher la position moyenne de chacun des quatre personnages avec une boucle.
// (C'est-à-dire la somme de ses positions divisée par le nombre de courses jouées)
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function calculerPositionMoyenne(){



}

// █████████████████████████████████████████████████████████████████████████
// 🌈 DLC B : C'est zouli 🌈
// █████████████████████████████████████████████████████████████████████████

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO B-1 : Mettre gAnimationEtoile à true. Ça activera l'animation.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

let gAnimationEtoile = false;

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO B-2 : Compléter animationEtoile()
//
// Cette fonction a 4 paramètres :
//   → tempsRestant : un nombre de 1 à 160
//   → elementImg : L'élément HTML <img> avec l'animation à placer sur le joueur.
//   → x : La position left du joueur
//   → y : La position top du joueur
//
// - Dans tous les cas, on modifie les styles left, top et zIndex de l'élément
//   <img> reçu en paramètre. Pour left, on met x - 16 pixels. Pour top, on met
//   y - 16 pixels. Pour zIndex, on met y + 1. (zIndex n'a pas besoin d'une
//   unité de mesure comme "px") Ceci placera l'image animée par-dessus le joueur !
// - Si le temps restant est 160, on doit aussi rendre visible l'image.
// - Si le temps restant est 1, on doit aussi rendre invisible l'image.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function animationEtoile(tempsRestant, elementImg, x, y){



}

// █████████████████████████████████████████████████████████████████████████
// 🔫 DLC C : 360 no scope 🔫
// █████████████████████████████████████████████████████████████████████████

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO C-1 : Compléter la fonction cacherWow()
//
// - Ajoutez simplement la classe "invisible" à l'élément .wow.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function cacherWow(){



}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO C-2 : Compléter la fonction noScopeWow()
//
// ⭐ Il y a des indices supplémentaires dans l'énoncé Web ⭐
//
// - Cette fonction possède 1 paramètre :
//      → indexJoueur : Représente l'index de l'<img> d'un joueur (0, 1, 2 ou 3) 
//        dans le tableau gJoueurs.
//
// - Si l'élément .wow possède la classe "invisible" :
//      - Placer l'élément .wow 20 pixels en haut à gauche de l'image du
//        joueur.
//      - Retirer la classe "invisible" à l'élément .wow.
//      - Appeler la fonction cacherWow() dans 800 millisecondes.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function noScopeWow(indexDuJoueur){



}

// █████████████████████████████████████████████████████████████████████████
// 😃 DLC D : Supplice visuel 😃
// █████████████████████████████████████████████████████████████████████████

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO D-1 : Mettre gEmojiActif à true. Ça activera l'existence de l'item.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

let gEmojiActif = false;

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO D-2 : Compléter la fonction choisirEmoji()
//
// Pour que ce ne soit pas toujours l'émoji 😃 qui apparaisse, cette fonction
// va ajouter un peu d'aléatoire dans le choix de l'émoji !
//
// - Le but est simplement de retourner une valeur aléatoire parmi ces trois :
//      - Dans 75% des cas : "😃"
//      - Dans 20% des cas : "🤬"
//      - Dans 5% des cas : "💩"
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function choisirEmoji(){



}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO D-3 : Compléter la fonction placerEmoji()
//
// ⭐ Il y a des indices supplémentaires dans l'énoncé Web ⭐
//
// - Cette fonction possède 2 paramètres :
//      → indexJoueur : Représente l'index de l'<img> d'un joueur (0, 1, 2 ou 3) 
//        dans le tableau gJoueurs.
//      → indexSmiley : Représente l'index de l'élément avec la classe ".emoji"
//                      si on crée un tableau des éléments avec la classe ".emoji".
//
// - Le but est de placer l'émoji avec l'index donné 41 pixels à gauche et
//   39 pixels en haut du joueur avec l'index donné. Attention ! Initialement,
//   l'émoji est caché à cause de display = "none". N'oubliez donc pas de le rendre
//   visible.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function placerEmoji(indexJoueur, indexSmiley){


    
}



// █████████████████████████████████████████████████████████████████████████
// 🔍 DLC E : Konami Code 🔍
// █████████████████████████████████████████████████████████████████████████

// Code Konami (Ne pas modifier. À utiliser pour comparer avec gCode)
let gKonamiCode = ["ArrowUp", "ArrowUp", "ArrowDown", "ArrowDown", "ArrowLeft",
    "ArrowRight", "ArrowLeft", "ArrowRight", "b", "a"];

// Code entré par l'utilisateur
let gCode = [];

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO E-1 : Compléter la fonction ajoutAuCode().
//
// - Cette fonction est déjà appelée lorsqu'il y a un événement clavier. (Pas 
//   besoin de créer un écouteur d'événement !)
// - Ajoutez simplement la touche appuyée à la fin du tableau gCode.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function ajoutAuCode(event){



}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO E-2 : Compléter la fonction validerCode().
//
// ⭐ Il y a des indices supplémentaires dans l'énoncé Web ⭐
//
// - Si la taille des tableaux gCode et gKonamiCode sont identiques ET
//   que toutes les valeurs dans gCode sont bonnes, on retourne true.
//   (Vous êtes obligés d'utiliser une boucle pour comparer les valeurs dans
//   les deux tableaux !)
// - Si les tailles des deux tableaux sont différents ou que la moindre
//   valeur dans gCode n'est pas bonne, on retourne false.
//
// - Dans TOUS LES CAS, on remplace gCode par un tableau vide avant de 
//   terminer la fonction. Comme cela, que le code donné soit bon ou mauvais,
//   il y a un reset pour réessayer.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function validerCode(){



}

// █████████████████████████████████████████████████████████████████████████
// 🥊 DLC F : Hey tasse-toé 🥊
// █████████████████████████████████████████████████████████████████████████

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO F-1 : Mettre gOndeActive à true. Ça activera l'existence de l'item.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

let gOndeActive = false;

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO F-2 : Compléter pousserEnnemisProches()
//
// ⭐ Il y a des indices supplémentaires dans l'énoncé Web ⭐
//
// Cette fonction reçoit 4 paramètres :
//   → x : La position left du joueur qui utilise l'onde de choc.
//   → y : La position top du joueur qui utilise l'onde de choc.
//   → xJoueurs : Un tableau qui contient la position left des 4 joueurs,
//     par exemple : [422, 322, 233, 342]
//   → yJoueurs : Un tableau qui contient la position top des 4 joueurs.
//
// Le but de la fonction est de créer et retourner un tableau avec 4 booléens pour
// dire au code quels joueurs parmi les 4 il faut pousser. (Ex : si on retourne
// [true, false, false, true], ça veut dire qu'on pousse les joueurs 1 et 4)
// On veut seulement pousser les ennemis à 60 de distance ou moins. On ne 
// veut jamais repousser le joueur lui-même. (Qui est à 0 de distance de lui-même)
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function pousserEnnemisProches(x, y, xJoueurs, yJoueurs){



}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// Ne pas modifier le code à partir d'ici
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

// proute
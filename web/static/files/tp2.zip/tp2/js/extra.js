let zUpdateFrequency = 10;
let zFrameDuration = 125;
let zMoveDuration = 125 * 4;
let zPlayers = [];
let zArrows = [];
let zRockets = [];
let zFlyingRockets = [];
let zCells = [];
let zChrono = 0;
let zWatchInterval = null;

// #region Fonctions variées pour fonctionnement du jeu
function setupGame() {

    setInterval(update, zUpdateFrequency);
    document.querySelector(".annuler").addEventListener("click", stopGame);
    document.addEventListener("keydown", appuyerTouches);
    document.addEventListener("keyup", relacherTouches);
    zCells = document.querySelectorAll(".case");
    let prepButtons = document.querySelectorAll(".preparer");
    for (let i = 0; i < prepButtons.length; i++) {
        prepButtons[i].addEventListener("click", function () { newGame(i + 1); });
    }

}

function newGame(nbPlayers) {

    zPlayers = [];
    let paints = ["rgb(255, 80, 54)", "rgb(247, 213, 61)", "rgb(75, 182, 240)", "rgb(86, 219, 68)"];
    let colors = ["red", "yellow", "blue", "green"];
    let controls = [new Controls("a", "d", "w", "s"), new Controls("ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown"), new Controls("j", "l", "i", "k"), new Controls("4", "6", "8", "5")];
    let directions = ["right", "right", "left", "left"];
    let x = [0, 0, 7, 7];
    let y = [0, 7, 0, 7];
    for (let i = 0; i < 4; i++) {
        if (i < nbPlayers) {
            zPlayers.push(new Player(i + 1, x[i], y[i], colors[i], paints[i], controls[i], directions[i]));
        }
        else {
            zPlayers.push(new CPU(i + 1, x[i], y[i], colors[i], paints[i], directions[i]));
        }
        document.querySelector(".joueur" + (i + 1)).style.display = "block";
        document.querySelector(".ombre" + (i + 1)).style.display = "block";
    }
    preparerPartie(nbPlayers);

}

function launchGame() {

    console.log("Début de la partie.");
    document.querySelector(".chrono").style.display = "block";
    zChrono = 30;
    document.querySelector(".chrono").textContent = zChrono;
    zWatchInterval = setInterval(updateWatch, 1000);
    console.log("Affichage du chrono.");

}

function updateWatch() {

    zChrono -= 1;
    document.querySelector(".chrono").textContent = zChrono;

    if (zChrono == 0) {
        clearInterval(zWatchInterval);
        document.querySelector(".chrono").style.display = "none";
        zWatchInterval = null;
        afficherScores();
        stopGame();
    }

}

function stopGame() {

    clearInterval(gPlanifDecompte);

    gJeuActif = false;

    document.querySelector(".jouer").style.display = "none";
    document.querySelector(".annuler").style.display = "none";
    document.querySelector(".decompte").style.display = "none";
    document.querySelector(".difficulte").style.display = "block";

    let boutonPreparations = document.querySelectorAll(".preparer");
    let j = 0;
    while (j < boutonPreparations.length) {
        boutonPreparations[j].style.display = "block";
        document.querySelector(".controles" + (1 + j)).style.display = "none";
        j += 1;
    }

    if (zWatchInterval != null) clearInterval(zWatchInterval);
    document.querySelector(".chrono").style.display = "none";

    let cases = document.querySelectorAll(".case");

    let k = 0;
    while (k < cases.length) {
        cases[k].style.backgroundColor = "rgb(225, 221, 255)";
        k += 1;
    }

    for (let i = 0; i < 4; i++) {
        document.querySelector(".joueur" + (i + 1)).style.display = "none";
        document.querySelector(".ombre" + (i + 1)).style.display = "none";
    }
    for (let p of zPlayers) {
        if (p.ornament != null) p.ornament.remove();
    }
    zPlayers = [];

    for (let r of zRockets) r.destroy();
    zRockets = [];
    for (let a of zArrows) a.destroy();
    zArrows = [];
    for (let f of zFlyingRockets) f.destroy();
    zFlyingRockets = [];

}

function update() {

    for (let p of zPlayers) {
        p.update();
        colorCell(p.x, p.y, p.paint);
    }

    if (!gJeuActif) return;

    tryToAddArrow();
    tryToAddRocket();

    for (let i = zArrows.length - 1; i >= 0; i--) {
        zArrows[i].update();
        if (zArrows[i].toRemove) {
            zArrows.splice(i, 1);
        }
    }

    for (let i = zRockets.length - 1; i >= 0; i--) {
        zRockets[i].update();
        if (zRockets[i].toRemove) {
            zRockets.splice(i, 1);
        }
    }

    for (let i = zFlyingRockets.length - 1; i >= 0; i--) {
        zFlyingRockets[i].update();
        if (zFlyingRockets[i].toRemove) {
            zFlyingRockets.splice(i, 1);
        }
    }

}

function tryToAddArrow() {

    if (zArrows.length < 2 && Math.random() * Math.pow(2 - zArrows.length, 2) > 0.98) {

        let added = false;
        while (!added) {

            let x = Math.floor(Math.random() * 8);
            let y = Math.floor(Math.random() * 8);
            let tooClose = false;

            for (let p of zPlayers) {
                if (Math.pow(p.x - x, 2) + Math.pow(p.y - y, 2) < 4.5) tooClose = true;
            }
            for (let r of zRockets) {
                if (r.x == x && r.y == y) tooClose = true;
            }
            if (zArrows.length > 0 && zArrows[0].x == x && zArrows[0].y == y) tooClose = true;

            if (!tooClose) {
                zArrows.push(new Arrow(x, y));
                added = true;
            }

        }

    }

}

function tryToAddRocket() {

    if (zRockets.length < 2 && Math.random() > 0.99) {

        let added = false;
        while (!added) {

            let x = Math.floor(Math.random() * 8);
            let y = Math.floor(Math.random() * 8);
            let tooClose = false;

            for (let p of zPlayers) {
                if (Math.pow(p.x - x, 2) + Math.pow(p.y - y, 2) < 4.5) tooClose = true;
            }
            for (let a of zArrows) {
                if (a.x == x && a.y == y) tooClose = true;
            }
            if (zRockets.length > 0 && zRockets[0].x == x && zRockets[0].y == y) tooClose = true;

            if (!tooClose) {
                zRockets.push(new Rocket(x, y));
                added = true;
            }

        }

    }

}

function colorCell(x, y, color) {

    let index = x + y * 8;
    if (zCells[index].style.backgroundColor != color) zCells[index].style.backgroundColor = color;

}

function appuyerTouches(e) {
    if (e.key == "ArrowUp" || e.key == "ArrowDown" || e.key == "ArrowLeft" || e.key == "ArrowRight") {
        e.preventDefault();
    }
    gererTouches(e.key, true);
}

function relacherTouches(e) {
    gererTouches(e.key, false);
}

function gererTouches(touche, bool) {
    for (let index = 0; index < zPlayers.length; index += 1) {
        zPlayers[index].updateKeys(touche, bool);
    }
}
// #endregion

// #region Classes
class Player {

    constructor(num, x, y, color, paint, controls, direction) {
        this.num = num;
        this.x = x;
        this.y = y;
        this.left = 0;
        this.top = 0;
        this.color = color;
        this.paint = paint;
        this.transition = 0;
        this.animation = 0;
        this.frame = 1;
        this.goingUp = true;
        this.controls = controls;
        this.direction = direction;
        this.state = "idle";
        this.character = document.querySelector(".joueur" + num);
        this.shadow = document.querySelector(".ombre" + num);
        this.hasRocket = false;
        this.hitbox = new Hitbox(7 + this.x * 56 + 6, -39 + this.y * 46 + 30, 28, 32);
        this.stunned = false;
        this.ornament = null;
    }

    update() {

        if (gJeuActif) {
            if (this.state == "move") {
                this.moveProgress();
            }
            if (!this.stunned && this.state == "idle"/* && this.frame == 1*/) {
                if (this.controls.upKeyActive) this.beginMove("up");
                else if (this.controls.downKeyActive) this.beginMove("down");
                else if (this.controls.leftKeyActive) this.beginMove("left");
                else if (this.controls.rightKeyActive) this.beginMove("right");
                //this.controls.deactivateAll();
            }
        }

        this.animation += zUpdateFrequency;

        if (this.animation >= zFrameDuration) {
            this.animation = 0;

            if (this.stunned && this.state == "idle") {
                this.frame = (this.frame + 1) % 4;
                if (this.frame == 0) this.frame += 1;
                this.ornament.src = "images/stunned" + (this.frame - 1) + ".png";
                this.transition -= zFrameDuration;
                if (this.transition <= 0) {
                    this.stunned = false;
                    this.ornament.remove();
                    this.ornament = null;
                }
            }
            else this.updateSprite();
        }

    }

    updateKeys(keyValue, onOrOff) {
        if (keyValue == this.controls.upKey) { this.controls.deactivateAll(); this.controls.upKeyActive = onOrOff; }
        if (keyValue == this.controls.downKey) { this.controls.deactivateAll(); this.controls.downKeyActive = onOrOff; }
        if (keyValue == this.controls.leftKey) { this.controls.deactivateAll(); this.controls.leftKeyActive = onOrOff; }
        if (keyValue == this.controls.rightKey) { this.controls.deactivateAll(); this.controls.rightKeyActive = onOrOff; }
    }

    updateSprite() {

        if (this.goingUp) {
            if (this.frame < 3) this.frame += 1;
            else {
                this.goingUp = false;
                this.frame -= 1;
            }
        }
        else {
            if (this.frame > 1) this.frame -= 1;
            else {
                this.goingUp = true;
                this.frame += 1;
            }
        }

        let deltaX = 0; let deltaY = 0;
        if (this.state == "move") {
            if (this.direction == "right") deltaX += (zMoveDuration - this.transition) / zMoveDuration * 56;
            if (this.direction == "left") deltaX -= (zMoveDuration - this.transition) / zMoveDuration * 56;
            if (this.direction == "up") deltaY -= (zMoveDuration - this.transition) / zMoveDuration * 46;
            if (this.direction == "down") deltaY += (zMoveDuration - this.transition) / zMoveDuration * 46;
        }

        this.character.style.left = 7 + this.x * 56 + deltaX + "px";
        this.character.style.top = -39 + this.y * 46 + deltaY + "px";
        this.character.style.zIndex = -39 + this.y * 46 + deltaY + 68;
        this.character.src = `images/${this.color}_${this.frame}_${this.direction}.png`;
        this.shadow.style.left = 14 + this.x * 56 + deltaX + "px";
        this.shadow.style.top = 22 + this.y * 46 + deltaY + "px";
        this.shadow.src = `images/shadow_${this.frame}.png`;
        this.hitbox.offset(7 + this.x * 56 + 6 + deltaX, -39 + this.y * 46 + 30 + deltaY);

        if (this.ornament != null) {
            this.ornament.style.zIndex = parseInt(this.character.style.zIndex) + 1;
            if (this.stunned) {
                this.ornament.style.top = parseInt(this.character.style.top) + 2 + "px";
                this.ornament.style.left = parseInt(this.character.style.left) + 2 + "px";
            }
            else {
                this.ornament.style.top = parseInt(this.character.style.top) - 14 + "px";
                this.ornament.style.left = parseInt(this.character.style.left) + 7 + "px";
            }
        }
    }

    beginMove(direction) {
        this.frame = 1;
        this.animation = 0;
        this.goingUp = true;
        this.direction = direction;
        this.character.src = `images/${this.color}_1_${this.direction}.png`;
        let newX = this.x + (this.direction == "right" ? 1 : 0) - (this.direction == "left" ? 1 : 0);
        let newY = this.y + (this.direction == "down" ? 1 : 0) - (this.direction == "up" ? 1 : 0);
        let occupied = false;
        for (let p of zPlayers) {
            if ((p.x == newX && p.y == newY) || (p.state == "move" && (
                (p.x + 1 == newX && p.y == newY && p.direction == "right") ||
                (p.x - 1 == newX && p.y == newY && p.direction == "left") ||
                (p.x == newX && p.y + 1 == newY && p.direction == "down") ||
                (p.x == newX && p.y - 1 == newY && p.direction == "up")
            ))) occupied = true;
        }
        if (!occupied && (direction == "up" && this.y > 0 || direction == "down" && this.y < 7
            || direction == "left" && this.x > 0 || direction == "right" && this.x < 7)) {
            this.state = "move";
            this.transition = zMoveDuration;
        }

    }

    moveProgress() {
        this.transition = Math.max(0, this.transition - zUpdateFrequency);
        if (this.transition == 0) {
            this.state = "idle";
            switch (this.direction) {
                case "up": this.y -= 1; break;
                case "down": this.y += 1; break;
                case "left": this.x -= 1; break;
                case "right": this.x += 1; break;
            }

            this.updateSprite();
            if (this.stunned) {
                this.freeze();
            }
        }
    }

    giveRocket() {
        if (!this.stunned && !this.hasRocket) {
            this.hasRocket = true;
            this.ornament = document.createElement("img");
            this.ornament.classList.add("objet");
            document.querySelector(".jeu").appendChild(this.ornament);
            this.ornament.src = "images/rocket.png";
            this.ornament.style.zIndex = parseInt(this.character.style.zIndex) + 1;
            this.ornament.style.top = parseInt(this.character.style.top) - 14 + "px";
            this.ornament.style.left = parseInt(this.character.style.left) + 7 + "px";
        }
    }

    useRocket() {
        if (!this.hasRocket) return;
        this.hasRocket = false;
        this.ornament.remove();
        this.ornament = null;
        zFlyingRockets.push(new FlyingRocket(this.x, this.y, "left", this));
        zFlyingRockets.push(new FlyingRocket(this.x, this.y, "right", this));
        zFlyingRockets.push(new FlyingRocket(this.x, this.y, "up", this));
        zFlyingRockets.push(new FlyingRocket(this.x, this.y, "down", this));
    }

    stun() {
        this.stunned = true;
        if (this.ornament != null) {
            this.ornament.remove();
            this.hasRocket = false;
        }
        this.ornament = document.createElement("img");
        this.ornament.classList.add("objet");
        document.querySelector(".jeu").appendChild(this.ornament);
        this.ornament.src = "images/stunned0.png";
        this.ornament.style.zIndex = parseInt(this.character.style.zIndex) + 1;
        this.ornament.style.top = parseInt(this.character.style.top) + 2 + "px";
        this.ornament.style.left = parseInt(this.character.style.left) + 2 + "px";
        if (this.state == "idle") this.freeze();
    }

    freeze() {
        this.transition = 2000;
        this.frame = 2;
        this.character.src = `images/${this.color}_${this.frame}_${this.direction}.png`;
        this.shadow.src = `images/shadow_${this.frame}.png`;
        this.ornament.style.zIndex = parseInt(this.character.style.zIndex) + 1;
    }

}

class CPU extends Player {

    constructor(num, x, y, color, paint, direction) {
        super(num, x, y, color, paint, new Controls("", "", "", ""), direction);
        this.moveDecision = 0;
        this.lastDirection = "";
    }

    update(){

        if (gJeuActif) {
            if (this.state == "move") {
                this.moveProgress();
            }
            if (!this.stunned && this.state == "idle") {
                if(this.hasRocket){
                    this.tryUseRocket();
                }
                this.moveDecision = Math.max(0, this.moveDecision - 1);
                if(this.moveDecision == 0){
                    this.moveDecision = Math.floor(Math.random() * (12 - gDifficulte * 4));
                    this.lastDirection = this.pickDirection();
                    this.beginMove(this.lastDirection);
                }
            }
        }

        this.animation += zUpdateFrequency;

        if (this.animation >= zFrameDuration) {
            this.animation = 0;

            if (this.stunned && this.state == "idle") {
                this.frame = (this.frame + 1) % 4;
                if (this.frame == 0) this.frame += 1;
                this.ornament.src = "images/stunned" + (this.frame - 1) + ".png";
                this.transition -= zFrameDuration;
                if (this.transition <= 0) {
                    this.stunned = false;
                    this.ornament.remove();
                    this.ornament = null;
                }
            }
            else this.updateSprite();
        }

    }

    pickDirection(){
        let scores = [this.getCellScore(this.x - 1, this.y, "left"), this.getCellScore(this.x + 1, this.y, "right"), 
            this.getCellScore(this.x, this.y - 1, "up"), this.getCellScore(this.x, this.y + 1, "down")];
        
        let total = scores[0] + scores[1] + scores[2] + scores[3];
        let r = 1 + Math.floor(Math.random() * total);
        
        for(let i = 0; i < scores.length; i++){
            r -= scores[i];
            if(r <= 0){
                switch(i){
                    case 0 : return "left";
                    case 1 : return "right";
                    case 2 : return "up";
                    case 3 : return "down";
                }
            }
        }

        return "down";
    }

    getCellScore(x,y,direction){
        if(x < 0 || x > 7 || y < 0 || y > 7) return 0;

        let cellColor = zCells[x + y * 8].style.backgroundColor;
        let cellBusy = false;
        let hasItem = false;
        let itemProximity = 128;

        for(let p of zPlayers) if(p.x == x && p.y == y) cellBusy = true;

        if(gDifficulte == 3 & cellBusy) return 0; 

        for(let r of zRockets){
            if(r.x == x && r.y == y && !(this.x == r.x && this.y == r.y)) hasItem = true;
            itemProximity = Math.min(itemProximity, Math.pow(r.x - x, 2) + Math.pow(r.y - y, 2));
        }
        for(let a of zArrows){
            if(a.x == x && a.y == y && !(this.x == a.x && this.y == a.y)) hasItem = true;
            itemProximity = Math.min(itemProximity, Math.pow(a.x - x, 2) + Math.pow(a.y - y, 2));
        }

        let s1 = cellColor == this.paint ? (8 - gDifficulte * 2) : (cellColor == "rgb(225, 221, 255)" ? (2 + gDifficulte * 8) : (6 + (gDifficulte-1) * 16));
        let s2 = cellBusy ? 0 : (gDifficulte - 1) * 2;
        let s3 = hasItem ? (gDifficulte - 1) * 75 : 0;
        let s4 = itemProximity <= 1 ? (gDifficulte - 1) * 30 : 0;
        let s5 = direction == this.lastDirection ? 3 : 0;

        return s1 + s2 + s3 + s4 + s5;
    }

    tryUseRocket(){
        let enemyInSight = false;
        for(let p of zPlayers) if((p.x == this.x || p.y == this.y) && p != this) enemyInSight = true;

        let r = Math.random() + (enemyInSight ? gDifficulte * 0.25 : (3 - gDifficulte) * 0.25);
        if(r > 1) this.useRocket();
    }
}

class Controls {
    constructor(leftKey, rightKey, upKey, downKey) {
        this.leftKey = leftKey;
        this.leftKeyActive = false;
        this.rightKey = rightKey;
        this.rightKeyActive = false;
        this.upKey = upKey;
        this.upKeyActive = false;
        this.downKey = downKey;
        this.downKeyActive = false;
    }

    deactivateAll() {
        this.leftKeyActive = false;
        this.rightKeyActive = false;
        this.upKeyActive = false;
        this.downKeyActive = false;
    }
}

class Arrow {

    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.direction = Math.floor(Math.random() * 4) * 4 + 1;
        this.transition = 1000;
        this.offset = 0;
        this.element = document.createElement("img");
        this.element.src = "images/arrow_" + this.direction + ".png";
        this.element.classList.add("objet");
        document.querySelector(".jeu").appendChild(this.element);
        this.element.style.left = 12 + this.x * 56 + "px";
        this.element.style.top = 8 + this.y * 46 + "px";
        this.toRemove = false;
        this.popped = false;
    }

    update() {
        this.transition -= zUpdateFrequency;

        if (this.popped) {
            if (this.transition % 100 == 0) {
                this.offset += 1;
                this.element.src = "images/pop" + (this.offset + 1) + ".png";
                if (this.transition == 0) {
                    this.destroy();
                }
            }
        }
        else {
            if (this.transition == 50 || this.transition == 100 || this.transition == 150) {
                this.offset += 1;
                this.updateSprite();
            }
            if (this.transition == 0) {
                this.direction = (this.direction + 4) % 17;
                if (this.direction == 0) this.direction += 1;
                this.offset = 0;
                this.transition = 1000;
                this.updateSprite();
            }
            this.checkPlayers();
        }
    }

    destroy() {
        this.toRemove = true;
        this.element.remove();
    }

    updateSprite() {
        let index = (this.direction + this.offset) % 17;
        if (index == 0) index += 1;
        this.element.src = "images/arrow_" + index + ".png";
    }

    checkPlayers() {

        for (let p of zPlayers) {
            if (p.x == this.x && p.y == this.y) {
                this.activate(p.paint);
                break;
            }
        }

    }

    activate(color) {
        let minX = 0;
        let maxX = 8;
        let minY = 0;
        let maxY = 8;
        let isX = true;
        switch (this.direction) {
            case 1: minX = this.x; break;
            case 5: minY = this.y; isX = false; break;
            case 9: maxX = this.x; break;
            case 13: maxY = this.y; isX = false; break;
        }
        let cases = document.querySelectorAll(".case");
        for (let i = (isX ? minX : minY); i < (isX ? maxX : maxY); i++) {
            let index = isX ? (i + this.y * 8) : (this.x + i * 8);
            cases[index].style.backgroundColor = color;
        }
        this.popped = true;
        this.transition = 400;
        this.offset = 0;
        this.element.src = "images/pop1.png";
        this.element.style.left = parseInt(this.element.style.left) - 6 + "px";
        this.element.style.top = parseInt(this.element.style.top) - 4 + "px";
    }

}

class Rocket {

    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.transition = 150;
        this.rotation = 0;
        this.element = document.createElement("img");
        this.element.src = "images/rocket0.png";
        this.element.classList.add("objet");
        document.querySelector(".jeu").appendChild(this.element);
        this.element.style.left = 16 + this.x * 56 + "px";
        this.element.style.top = 2 + this.y * 46 + "px";
        this.toRemove = false;
        this.popped = false;
    }

    update() {
        this.transition -= zUpdateFrequency;

        if (this.popped) {
            if (this.transition % 100 == 0) {
                this.offset += 1;
                this.element.src = "images/pop" + (this.offset + 1) + ".png";
                if (this.transition == 0) {
                    this.destroy();
                }
            }
        }
        else {
            if (this.transition == 0) {
                this.transition = 150;
                this.rotation = (this.rotation + 1) % 3;
                this.updateSprite();
            }
            this.checkPlayers();
        }

    }

    updateSprite() {
        this.element.src = "images/rocket" + this.rotation + ".png";
    }

    checkPlayers() {

        for (let p of zPlayers) {
            if (p.x == this.x && p.y == this.y) {
                this.popped = true;
                this.giveToPlayer(p);
                break;
            }
        }

    }

    destroy() {
        this.toRemove = true;
        this.element.remove();
    }

    giveToPlayer(player) {
        this.transition = 400;
        this.offset = 0;
        this.element.src = "images/pop1.png";
        this.element.style.left = parseInt(this.element.style.left) - 8 + "px";
        player.giveRocket();
    }

}

class FlyingRocket {

    constructor(x, y, direction, player) {
        this.owner = player;
        this.direction = direction;
        this.element = document.createElement("img");
        this.element.src = "images/" + this.direction + "Rocket0.png";
        this.element.classList.add("objet");
        document.querySelector(".jeu").appendChild(this.element);
        let posX = x * 56;
        let posY = y * 46;
        let offX = 0;
        let offY = 0;
        let width = 0;
        let height = 0;
        switch (this.direction) {
            case "left": posX -= 28; posY += 8; offX = 4; width = 22; height = 28; break;
            case "right": posX += 30; posY += 8; offX = 28; width = 22; height = 28; break;
            case "up": posX += 14; posY -= 30; offY = 20; width = 28; height = 22; break;
            case "down": posX += 14; posY += 22; offY = 4; width = 28; height = 22; break;
        }
        this.x = posX;
        this.y = posY;
        this.hitbox = new Hitbox(this.x + offX, this.y + offY, width, height);
        this.offX = offX;
        this.offY = offY;
        this.element.style.left = this.x + "px";
        this.element.style.top = this.y + "px";
        this.element.style.zIndex = this.y + 34;
        this.transition = 100;
        this.frame = 0;
        this.speed = 1;
        this.toRemove = false;
        this.popped = false;
    }

    update() {

        this.transition -= zUpdateFrequency;

        if (this.popped) {
            if (this.transition % 100 == 0) {
                this.offset += 1;
                this.element.src = "images/pop" + (this.offset + 1) + ".png";
                if (this.transition == 0) {
                    this.destroy();
                }
            }
        }
        else {
            this.speed += 0.25;
            if (this.transition == 0) {
                this.transition = 100;
                this.frame = (this.frame + 1) % 3;
                this.element.src = "images/" + this.direction + "Rocket" + this.frame + ".png";
            }

            switch (this.direction) {
                case "left": this.x -= this.speed; break;
                case "right": this.x += this.speed; break;
                case "up": this.y -= this.speed; break;
                case "down": this.y += this.speed; break;
            }
            this.hitbox.offset(this.x + this.offX, this.y + this.offY);
            this.updateSprite();
            this.checkPlayers();
        }
    }

    checkPlayers() {

        if (this.x < -60 || this.y < -60 || this.x > 460 || this.y > 380) {
            this.popped = true;
            this.transition = 400;
            this.offset = 0;
            this.element.src = "images/pop1.png";
            this.element.style.left = parseInt(this.element.style.left) - 6 + (this.direction == "right" ? 24 : 0) + "px";
            this.element.style.top = parseInt(this.element.style.top) - 4 + (this.direction == "down" ? 18 : 0) + "px";
            return;
        }

        for (let p of zPlayers) {
            if (p != this.owner && p.hitbox.intersects(this.hitbox)) {
                p.stun();
                this.popped = true;
                this.transition = 400;
                this.offset = 0;
                this.element.src = "images/pop1.png";
                this.element.style.left = parseInt(this.element.style.left) - 6 + (this.direction == "right" ? 24 : 0) + "px";
                this.element.style.top = parseInt(this.element.style.top) - 4 + (this.direction == "down" ? 18 : 0) + "px";
                break;
            }
        }
    }

    updateSprite() {
        this.element.style.left = this.x + "px";
        this.element.style.top = this.y + "px";
        if (this.direction == "left" || this.direction == "right") this.element.style.zIndex = this.y + 34;
    }

    destroy() {
        this.toRemove = true;
        this.element.remove();
    }
}

class Hitbox {

    constructor(x, y, width, height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    offset(x, y) {
        this.x = x;
        this.y = y;
    }

    intersects(hitbox) {
        return this.x < hitbox.x + hitbox.width && hitbox.x < this.x + this.width
            && this.y < hitbox.y + hitbox.height && hitbox.y < this.y + this.height;
    }

}
// #endregion
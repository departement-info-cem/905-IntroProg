let zPlayers = [];
let zBananas = [];
let zReposBoost = [0, 0, 0, 0];
let zVitesseJoueurs = [0,0,0,0];
let zBananaIndex = 0;
let zRockets = [];
let zPushes;
let zRocketIndex = 0;
let zRaces = [];
let zRaceChoice = 0;
let zEmojiCooldown = 0;
let zEmojiMaxPosition = 0;

let zAffichageTours;
let zAffichageTourJoueurs;
let zPlaces = [0,0,0,0]
let zTimes = ["", "", "", ""];
let zBrigthnesses = [0,0,0,0];

let zMeteorDistance = 0;
let zMeteorDistanceRaising = true;

let zPositionMeteores = [0, 1.57, 3.15, 4.71];
let zChronometre = 0;
let zNbJoueurs = 0;

let zDernierTrou = 0;
let zDonutCooldown = 200;

let zBebeCooldown = 300;
let zTailleActuelle = 1;

function planificateurs(){
    document.addEventListener("keydown", appuyerTouches);
    document.addEventListener("keyup", relacherTouches);
    document.querySelector("#stop").addEventListener("click", finCourse)
    document.querySelector("#raceChoice1").addEventListener("click", function(){choixCourse(1)});
    document.querySelector("#raceChoice2").addEventListener("click", function(){choixCourse(2)});
    document.querySelector("#raceChoice3").addEventListener("click", function(){choixCourse(3)});
    document.querySelector("#raceChoice4").addEventListener("click", function(){choixCourse(4)});
    document.querySelector("#one").addEventListener("click", function(){preparerCourse(1)});
    document.querySelector("#two").addEventListener("click", function(){preparerCourse(2)});
    document.querySelector("#three").addEventListener("click", function(){preparerCourse(3)});
    document.querySelector("#four").addEventListener("click", function(){preparerCourse(4)});
    if(gPositionMoyenneAffichee){
        document.querySelector(".btnPositions").addEventListener("click", togglePositionsMoyennes);
        document.querySelector(".btnPositions").style.display = "block";
    }
    
    zAffichageTours = document.querySelectorAll(".tour");
    zAffichageTourJoueurs = document.querySelectorAll(".tourJoueur");
    setInterval(updateJeu, 25);
    //createPlayers();
    prepareRaces();
    hideBoxes();
    choixCourse(1);
    document.addEventListener("keydown", secretCode);
    zPushes = [new Point(0,0), new Point(0,0), new Point(0,0), new Point(0,0)];
}

function togglePositionsMoyennes(){

    let element = document.querySelector("#positionsMoyennes");
    if(element.style.display == "block"){
        element.style.display = "none";
    }
    else{
        element.style.display = "block";
        document.querySelector("#scores").style.display = "none";
    }

}

function lancerCourse(){
    document.querySelector(".go").style.display="none";
    
    document.addEventListener("keydown", appuyerTouches);
    document.addEventListener("keyup", relacherTouches);
    gPlanificateurDecompte = setInterval(decompte, 800);
    document.querySelector(".decompte").style.display = "block";
    let i = 0;
    while(i < zNbJoueurs){
        document.querySelector(".controls"+i).style.display="none";
        i += 1;
    }
}


function finCourse(){

    gDecompte = 3;
    let i = 0
    while(i < 4){
        gJoueurs[i].style.display = "none";
        gOmbres[i].style.display = "none";
        document.querySelector(".controls"+i).style.display="none";
        i += 1;
    }

    for(let e of document.querySelectorAll(".preparation")) e.style.display = "block";
    for(let e of document.querySelectorAll(".tour")) e.style.display = "none";
    document.querySelector(".difficulte").style.display="flex";
    
    retirerItems();

    document.querySelector(".go").style.display="none";
    document.querySelector("#stop").style.display="none";

    gCourseEnCours = false;
    clearInterval(gPlanificateurChrono);
    clearInterval(gPlanificateurDecompte);
    document.querySelector(".decompte").style.display = "none";
    document.querySelector(".decompte").textContent = 3;
    gDecompte = 3;
    
    document.removeEventListener("keydown", appuyerTouches);
    document.removeEventListener("keyup", relacherTouches);
    zPushes = [new Point(0,0), new Point(0,0), new Point(0,0), new Point(0,0)];

}

function affichageChrono(tempsEnSecondes){
    let seconds = tempsEnSecondes % 60;
    let minutes = (tempsEnSecondes - seconds) / 60;
    return (minutes < 10 ? "0" : "") + minutes + ":" + (seconds < 10 ? "0" : "") + seconds;
}

function augmenterChrono(){
    zChronometre += 1;
    document.querySelector("#chrono").textContent = affichageChrono(zChronometre);
}

function retirerItems(){
    for(let p of zPlayers){
        p.item = null;
        document.querySelector("#item" + (p.playerNum - 1)).style.display = "none";
        p.starCooldown = 0;
        p.bananaCooldown = 0;
    }
    for(let i = 0; i < 10; i++){
        document.querySelector("#banana" + i).style.display = "none";
    }
    zBananas = [];
    for(let i = 0; i < 6; i++){
        document.querySelector("#box" + i).style.display = "none";
    }
    boxes = [];
    for(let i = 0; i < 4 ; i++){
        document.querySelector("#rocket" + i).style.display = "none";
    }
    zRockets = [];
    zEmojiMaxPosition = 0;
    for(let e of document.querySelectorAll(".emoji")){
        e.style.display = "none";
    }
    for(let p of zPlayers){
        p.isSmileyed = false;
    }
}



function choixCourse(courseId){
    if(gCourseEnCours){
        return;
    }
    finCourse();
    for(let i = 1; i < 6; i++){
        if(i == courseId){
            document.querySelector("#race" + i).style.display = "block";
        }
        else{
            document.querySelector("#race" + i).style.display = "none";
        }  
    }
    for(let sp of zRaces[zRaceChoice].speedPads){
        sp.speedPadElem.style.display = "none";
    }
    zRaceChoice = courseId - 1;
    for(let sp of zRaces[zRaceChoice].speedPads){
        sp.speedPadElem.style.display = "block";
    }
    gNbDeTours = zRaces[zRaceChoice].nbTours;
    
    let meteores = document.querySelectorAll(".meteore");

    if(zRaceChoice == 1){
        for(let i = 0; i < meteores.length; i += 1){
            meteores[i].style.display = "block";
            meteores[i].style.left = (400 - parseInt(meteores[i].width) / 2 + Math.cos(zPositionMeteores[i]) * 150) + "px";
            meteores[i].style.top = (300 - parseInt(meteores[i].height) / 2 + Math.sin(zPositionMeteores[i]) * 150) + "px";
        }
    }
    else{
        for(let i = 0; i < meteores.length; i += 1){
            meteores[i].style.display = "none";
        }
    }
}

function verifierCheckpoints(){
    for(let index = 0; index < 4; index += 1){
        let player = zPlayers[index];
        let c = zRaces[zRaceChoice].checkpoints[(player.checkpointMarker+1)%zRaces[zRaceChoice].checkpoints.length];
        if(c.rectangleArea.isPointInRectangle(player.getLocation())){
            player.checkpointMarker = c.milestone;
            player.score++;
            if(c.milestone == 0){
                gTours[index] += 1;
                zAffichageTourJoueurs[index].textContent = " " + (gTours[index] < zRaces[zRaceChoice].nbTours ? gTours[index] +"/" + zRaces[zRaceChoice].nbTours : "Fini !");
                if(gTours[index] >= zRaces[zRaceChoice].nbTours){
                    gJoueurs[index].style.display = "none";
                    gOmbres[index].style.display = "none";
                    if(player.starImg != null) player.starImg.style.display = "none";
                    if(player.shockImg != null) player.shockImg.style.display = "none";
                    zPlayers[index].item = null;
                    gJoueurs[index].style.left = "0px";
                    document.querySelector("#item" + index).style.display = "none";
                    zVitesseJoueurs[index] = 0;
                    player.speed = 0; // ██???██
                    player.keyControls.deactivateAll();
                    player.isSmileyed = false;
                    zPlaces[index] = Math.max(...zPlaces) + 1;
                    zTimes[index] = affichageChrono(zChronometre);
                    if(courseEstElleFinie(zRaces[zRaceChoice].nbTours)){
                        for(let i = 0; i < 4; i++){
                            gSommePositions[i] += zPlaces[i];
                        }
                        gNbCoursesJouees += 1;
                        calculerPositionMoyenne();
                        trierScores();
                        afficherScores(zPlaces, zTimes);
                        finCourse();
                        console.log("Le joueur " + (index + 1) + " a fait son dernier tour et la course est terminée ! 🏁")
                    }
                    else{
                        console.log("Le joueur " + (index + 1) + " a terminé la course ! 🛸");
                    }
                }
            }
        }
    }
}

function verifierItems(){
    for(let index = 0; index < 4; index += 1){
        let player = zPlayers[index];
        let race = zRaces[zRaceChoice];
        if(player.item != null && player.itemCooldown > 0){
            player.itemCooldown -= 1;
            if(player.itemCooldown == 0){

                let r = Math.random();

                switch(getPosition(index)){
                    case 1: 
                        player.item = r > 0.3 ? "banana" : "rocket";
                        break;
                    case 2:
                        player.item = r < 0.3 ? "banana" : (r < 0.7 ? "rocket" : 
                            (gOndeActive ? "shockWave" : "mushroom"));
                        break;
                    case 3 :
                        if(gEmojiActif && r < 0.2){
                            player.item = "emoji";
                            break;
                        }
                        player.item = r < 0.6 ? "mushroom" : (gOndeActive ? "shockWave" : "rocket");
                        break;
                    default :
                        if(gEmojiActif && r < 0.3){
                            player.item = "emoji";
                            break;
                        }
                        player.item = r < 0.5 ? "mushroom" : "star";
                }
                document.querySelector("#item" + index).src = "images/"+player.item+".png";
            }
        }
        for(let boxIndex = 0; boxIndex < race.boxes.length; boxIndex++){
            let box = race.boxes[boxIndex];
            if(!box.isBroken && box.circleArea.isPointInCircle(player.getLocation())){
                box.break();
                if(player.item == null){
                    player.item = "wait";
                    player.itemCooldown = 40;
                    // Item au-dessus de la tête
                    document.querySelector("#item" + index).style.display = "block";
                    document.querySelector("#item" + index).src = "images/itemWait.gif";
                }   
            }
        }
    }
}

function verifierBananes(){
    for(let index = 0; index < 4; index += 1){
        for(let i = zBananas.length - 1; i >= 0; i--){
            if(zBananas[i].circleArea.isPointInCircle(zPlayers[index].getLocation())){
                let banana = document.querySelector("#banana" + zBananas[i].num);
                banana.style.display = "none";
                zBananas.splice(i, 1);
                if(zPlayers[index].starCooldown == 0){
                    zPlayers[index].disturb();
                }
                break;
            }
        }
    }
}

function verifierFusees(){
    for(let i = zRockets.length - 1; i >= 0; i--){
        zRockets[i].move();
        if(zRockets[i].rocketHealth <= 0 || !zRockets[i].positionValide){
            let rocket = document.querySelector("#rocket" + zRockets[i].num);
            rocket.style.display = "none";
            zRockets.splice(i, 1);
            continue;
        }
        for(let index = 0; index < 4; index += 1){
            if(zRockets[i].circleArea.isPointInCircle(zPlayers[index].getLocation())){
                let rocket = document.querySelector("#rocket" + zRockets[i].num);
                rocket.style.display = "none";
                zRockets.splice(i, 1);
                if(zPlayers[index].starCooldown == 0){
                    zPlayers[index].crash();
                }
                break;
            }
        }
    }
}

function boosterLeJoueur(indexJoueur){

    if(zReposBoost[indexJoueur] <= 0){
        zReposBoost[indexJoueur] = 20;
        zVitesseJoueurs[indexJoueur] += 10;
        gJoueurs[indexJoueur].classList.add("boost");
        setTimeout(finBoost, 500, indexJoueur);
        return true;
    }
    return false;

}

function reduireReposBoosts(){

    let i = 0;
    while(i < zReposBoost.length){
        if(zReposBoost[i] > 0){
            zReposBoost[i] -= 1;
        }
        i += 1;
    }

}

function verifierSpeedPads(){
    for(let p of zPlayers){
        if(zPlayers[p.playerNum - 1].imgElement.classList.contains("boost")){
            zBrigthnesses[p.playerNum - 1] -= 0.5;
            zPlayers[p.playerNum - 1].imgElement.style.filter = "brightness("+zBrigthnesses[p.playerNum - 1]+")";
        }
        if(!zPlayers[p.playerNum - 1].imgElement.classList.contains("boost")){
            zPlayers[p.playerNum - 1].imgElement.style.filter = "hue-rotate(0)";
        }
        let playerPosition = new Point(parseInt(p.imgElement.style.left) + 14, parseInt(p.imgElement.style.top) + 16);
        for(let sp of zRaces[zRaceChoice].speedPads){
            if(sp.isPointOnSpeedPad(playerPosition)){
                if(boosterLeJoueur(p.playerNum - 1)){
                    zPlayers[p.playerNum - 1].speed = zVitesseJoueurs[p.playerNum - 1];
                }
                if(zPlayers[p.playerNum - 1].imgElement.classList.contains("boost")){
                    zPlayers[p.playerNum - 1].imgElement.style.filter = "brightness(3)";
                    zBrigthnesses[p.playerNum - 1] = 3;
                }
            }
        }
    }
}

function finBoost(index){
    gJoueurs[index].classList.remove("boost");
}

function changerPositionMeteores(){

    if(zMeteorDistanceRaising){
        zMeteorDistance += 0.33;
        if(zMeteorDistance >= 100) zMeteorDistanceRaising = false;
    }
    else{
        zMeteorDistance -= 0.33;
        if(zMeteorDistance <= 0) zMeteorDistanceRaising = true;
    }
    let i = 0;
    while(i < zPositionMeteores.length){
        zPositionMeteores[i] += 0.01;
        if(zPositionMeteores[i] > 6.28){
            zPositionMeteores[i] -= 6.28;
        }
        i += 1;
    }

}

function updateMeteors(){
    if(zRaceChoice == 1){
        changerPositionMeteores();
        let meteores = document.querySelectorAll(".meteore");
        for(let i = 0; i < meteores.length; i += 1){
            let x = 400 - parseInt(meteores[i].width) / 2 + Math.cos(zPositionMeteores[i]) * (150 + zMeteorDistance);
            let y = 300 - parseInt(meteores[i].height) / 2 + Math.sin(zPositionMeteores[i]) * (150 + zMeteorDistance);
            meteores[i].style.left = x + "px";
            meteores[i].style.top = y + "px";
            x += parseInt(meteores[i].width) / 2;
            y += parseInt(meteores[i].height) / 2;
            for(let j = 0; j < 4; j += 1){
                let pos = zPlayers[j].getLocation().add(new Point(14, 14));
                if(Math.sqrt(Math.pow(x - pos.x, 2) + Math.pow(y - pos.y, 2)) < meteores[i].width / 2 + zPlayers[j].imgElement.width / 2 - 8 
                && !zPlayers[j].isImmune && zPlayers[j].starCooldown <= 0){
                    zPlayers[j].crash();
                }
            }
        }
    }
}

function updateEmojis(){

    if(zEmojiCooldown > 0){
        zEmojiCooldown -= 1;
        if(zEmojiCooldown <= 0){
            zEmojiMaxPosition = 0;
            for(let e of document.querySelectorAll(".emoji")){
                e.style.display = "none";
            }
            for(let p of zPlayers){
                p.isSmileyed = false;
            }
            return;
        }
        if(zEmojiCooldown >= 199){
            for(let e of document.querySelectorAll(".emoji")){
                e.textContent = choisirEmoji();
            }
            for(let i = 0; i < 4; i += 1){
                if(getPosition(i) <= zEmojiMaxPosition && gTours[i] < zRaces[zRaceChoice].nbTours) {
                    zPlayers[i].isSmileyed = true;
                }
            }
        }
        let indexEmoji = 0;
        for(let i = 0; i < 4; i += 1){
            if(zPlayers[i].isSmileyed && gTours[i] < zRaces[zRaceChoice].nbTours) {   
                placerEmoji(i, indexEmoji);
                indexEmoji += 1;
            }
        }
    }

}

function getPosition(index){
    let playerScore = zPlayers[index].score;
    let scores = [zPlayers[0].score, zPlayers[1].score, zPlayers[2].score, zPlayers[3].score];
    scores.sort((x,y)=>x > y);
    return 4 - scores.indexOf(playerScore);
}

function trierScores(){
    let playerNums = [1,2,3,4];
    for(let i = 0; i < 4 - 1; i++){
        let minIndex = i;
        for(let j = i + 1; j < 4; j++){
            if(zPlaces[minIndex] > zPlaces[j]){
                minIndex = j;
            }
        }
        invertDataInArray(zPlaces, i, minIndex);
        invertDataInArray(zTimes, i, minIndex);
        invertDataInArray(playerNums, i, minIndex);
    }
    let elements = document.querySelectorAll("[id^=score] img");
    for(let i = 0; i < 4; i++){
        elements[i].src = "images/p" + playerNums[i] + "Down.png";
    }
}

function invertDataInArray(array, index1, index2){
    let temp = array[index1];
    array[index1] = array[index2];
    array[index2] = temp;
}

function horsCourse(){
    for(let index = 0; index < 4; index +=1){
        let player = zPlayers[index];
        let point = new Point(player.getLocation().x + 14, player.getLocation().y + 18)
        if(gTours[index] < zRaces[zRaceChoice].nbTours && !player.hasCrashed && !zRaces[zRaceChoice].isPointSafe(point)){
            player.crash();
        }
    }
}

function secretCode(e){
    if(e.key != " "){
        ajoutAuCode(e);
    }
    if(e.key == " "){
        if(validerCode() && !gCourseEnCours){
            choixCourse(5);
        }
    }
}

function appuyerTouches(e){
	if(e.key == "ArrowUp" || e.key == "ArrowDown" || e.key == "ArrowLeft" || e.key == "ArrowRight"){
		e.preventDefault();
    }
    if(e.key == "ArrowDown" || e.key == "5" || e.key == "k" || e.key == "s"){
        activationItems(e);
    }
    if(e.key != "ArrowDown" && e.key != "5" && e.key != "k" && e.key != "s"){
        gererTouches(e.key, true);
    }
}

function relacherTouches(e){
    gererTouches(e.key, false);
}

function gererTouches(touche, bool){
    if(!gCourseEnCours)
        return;
    for(let index = 0; index < 4; index += 1){
        zPlayers[index].updateKeys(touche, bool);
    }
}

function updateJeu(){
    if(!gCourseEnCours)
        return;
    reduireReposBoosts();
    verifierCheckpoints();
    verifierItems();
    verifierBananes();
    verifierFusees();
    verifierSpeedPads();
    if(gOndeActive) verifierPoussee();
    updateMeteors();
    updateEmojis();
    horsCourse();
    for(let index = 0; index < 4; index += 1){
        if(zChronometre == 0 && gCourseEnCours){
            zPlayers[index].stopImmunity();
        }
        if(zPlayers[index].hasCrashed) continue;
        let vitesse = zVitesseJoueurs[index]; // ██???██
        if(gTours[index] >= zRaces[zRaceChoice].nbTours) continue;
        vitesse = zPlayers[index].speed;
        vitesse = zPlayers[index].getNewSpeed(vitesse);
        zPlayers[index].rotate();
        //zPlayers[index].activateItem();
        zPlayers[index].moveForward(vitesse);
        for(let i = index + 1; i < 4; i++){
            if(!zPlayers[i].isImmune && !zPlayers[index].isImmune && gTours[i] < zRaces[zRaceChoice].nbTours)
                verifierCollision(index, i);
        }
    }
}

function distanceEntreJoueurs(joueurA, joueurB){
    let xA = parseInt(joueurA.style.left);
    let yA = parseInt(joueurA.style.top);
    let xB = parseInt(joueurB.style.left);
    let yB = parseInt(joueurB.style.top);
    let distance = distanceEntreDeuxPositions(xA, yA, xB, yB);
    return distance;
}


// Retourne la distance en pixels entre deux points (x, y)
function distanceEntreDeuxPositions(x1, y1, x2, y2){
    return Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
}

function verifierCollision(index1, index2){

    let d = distanceEntreJoueurs(gJoueurs[index1], gJoueurs[index2]);
    if(d < 23){
        if(zPlayers[index1].starCooldown > 0 && zPlayers[index2].starCooldown <= 0 && !zPlayers[index2].isImmune){
            zPlayers[index2].crash();
        }
        else if(zPlayers[index2].starCooldown > 0 && zPlayers[index1].starCooldown <= 0){
            zPlayers[index1].crash();
        }
        else if(zPlayers[index1].speed > 2 || zPlayers[index2].speed > 2){
            let posJoueur1 = zPlayers[index1].getLocation();
            let posJoueur2 = zPlayers[index2].getLocation();
            let difference = posJoueur1.sub(posJoueur2);
            let distance = difference.length();
            difference = difference.normalize();

            zPlayers[index1].move(difference.x * (zPlayers[index2].speed * 15 / distance), 
                difference.y * (zPlayers[index2].speed * 15 / distance));
            zPlayers[index2].move(difference.x * -1 * (zPlayers[index1].speed * 15 / distance), 
                difference.y * -1 * (zPlayers[index1].speed * 15 / distance));
            
            if(zPlayers[index1].speed > zPlayers[index2].speed){
                zPlayers[index1].speed -= 0.5;
            }
            else{
                zPlayers[index2].speed -= 0.5;
            }
        }
    }
}

function verifierPoussee(){

    for(let i = 0; i < 4; i++){
        if(zPlayers[i].hasCrashed || gTours[i] >= zRaces[zRaceChoice].nbTours) continue;
        if(Math.abs(zPushes[i].x) > 1 || Math.abs(zPushes[i].y) > 1){
            zPlayers[i].move(zPushes[i].x, zPushes[i].y);
            zPushes[i] = zPushes[i].mul(0.5);
        }
    }

}

function ajouterSuffixePosition(p){
    if(p == 1){
        return "1er";
    }
    else{
        return p + "e";
    }
}

function scoreDuJoueur(place, chrono){
    return " " + place + " - " + chrono;
}

function afficherScores(positions, temps){
    for(let index = 0; index < 4; index +=1){
        let positionDuJoueur = positions[index];
        let positionAvecSuffixe = ajouterSuffixePosition(positionDuJoueur);
        let score = scoreDuJoueur(positionAvecSuffixe, temps[index]);
        document.querySelector("#scoreJoueur"+index).textContent = score;
        document.querySelector("#score"+index).style.display = "block";
    }

    document.querySelector("#scores").style.display = "block";

}

function prepareRaces(){
    let offSets = [new Point(175, 150)];
    zRaces = [
        new Race(
            // Safe circle areas
            [new CircleArea(new Point(153 + offSets[0].x, 152 + offSets[0].y), 149), new CircleArea(new Point(302 + offSets[0].x, 152 + offSets[0].y), 149)], // Two big circles
            // Safe triangle areas
            [],
            // Safe rectangle areas
            [new RectangleArea(new Point(143 + offSets[0].x, 3 + offSets[0].y), new Point(312 + offSets[0].x, 302 + offSets[0].y))], // Big rectangle
            // Circle holes
            [new CircleArea(new Point(153 + offSets[0].x, 152 + offSets[0].y), 25), new CircleArea(new Point(302 + offSets[0].x, 152 + offSets[0].y), 25)], // Two small circle holes
            // Triangle holes
            [],
            // Rectangle holes
            [new RectangleArea(new Point(149 + offSets[0].x, 126 + offSets[0].y), new Point(302 + offSets[0].x, 177 + offSets[0].y))], // Small rectangle hole
            // Checkpoints
            [
                new CheckPoint(new Point(258 - 14 + offSets[0].x, 62 - 14 + offSets[0].y), new RectangleArea(new Point(211 + offSets[0].x,-15 + offSets[0].y), new Point(292 + offSets[0].x,127 + offSets[0].y)), 0, 12),
                new CheckPoint(new Point(389 - 14 + offSets[0].x, 149 - 14 + offSets[0].y), new RectangleArea(new Point(306 + offSets[0].x, 125 + offSets[0].y), new Point(454 + offSets[0].x, 186 + offSets[0].y)), 1, 0),
                new CheckPoint(new Point(209 - 14 + offSets[0].x, 235 - 14 + offSets[0].y), new RectangleArea(new Point(169 + offSets[0].x, 155 + offSets[0].y), new Point(248 + offSets[0].x, 304 + offSets[0].y)), 2, 4),
                new CheckPoint(new Point(69 - 14 + offSets[0].x, 150 - 14 + offSets[0].y), new RectangleArea(new Point(0 + offSets[0].x, 126 + offSets[0].y), new Point(148 + offSets[0].x, 179 + offSets[0].y)), 3, 8)
            ],
            // Spawns
            [new Point(196 + offSets[0].x - 14, 20 + offSets[0].y - 14), new Point(171 + offSets[0].x - 14, 45 + offSets[0].y - 14), new Point(146 + offSets[0].x - 14, 70 + offSets[0].y - 14), new Point(121 + offSets[0].x - 14, 95 + offSets[0].y - 14)],
            // Spawn rotation (Right)
            12,
            // Speed pads
            [new SpeedPad(279 + 175, 254 + 150, "Gauche")],
            // Race HTML <img>
            document.querySelector("#race1"),
            // Item boxes
            [
                new ItemBox(new CircleArea(new Point(380 + 11, 330 + 14), 20), document.querySelector("#box0")),
                new ItemBox(new CircleArea(new Point(380 + 11, 380 + 14), 20), document.querySelector("#box1")),
                new ItemBox(new CircleArea(new Point(188 + 11, 270 + 14), 20), document.querySelector("#box2")),
                new ItemBox(new CircleArea(new Point(573 + 11, 270 + 14), 20), document.querySelector("#box3"))
            ],
            5,
            // Left path points
            [new Point(421, 152), new Point(496, 153), new Point(538, 165), new Point(582, 196),
             new Point(615, 245), new Point(626, 301), new Point(615, 359), new Point(583, 405),
             new Point(544, 435), new Point(492, 450), new Point(422, 451), new Point(374, 451),
             new Point(311, 450), new Point(259, 435), new Point(220, 405), new Point(188, 359),
             new Point(177, 301), new Point(188, 245), new Point(221, 196), new Point(265, 165),
             new Point(307, 153), new Point(378, 152)],
            // Right path points
            [new Point(421, 276), new Point(477, 276), new Point(487, 278), new Point(494, 284),
             new Point(500, 291), new Point(502, 301), new Point(500, 310), new Point(496, 318),
             new Point(488, 324), new Point(478, 327), new Point(422, 327), new Point(374, 327),
             new Point(325, 327), new Point(315, 324), new Point(307, 318), new Point(303, 310),
             new Point(301, 301), new Point(303, 291), new Point(309, 284), new Point(316, 278),
             new Point(326, 276), new Point(378, 276)],
             // Checkpoint targets
             [1, 6, 12, 17],
             // Left side is best ?
             [false, false, false, false, false, false, false, false, false, false, false,
              false, false, false, false, false, false, false, false, false, false, false]
        ),
        new Race(
            // Safe circle areas
            [new CircleArea(new Point(300, 400), 150), new CircleArea(new Point(500, 200), 150)],
            // Safe triangle areas
            [],
            // Safe rectangle areas
            [new RectangleArea(new Point(350,200), new Point(449, 399)), new RectangleArea(new Point(300,250), new Point(499, 349))],
            // Circle holes
            [new CircleArea(new Point(300, 400), 50), new CircleArea(new Point(500, 200), 50)],
            // Triangle holes
            [new TriangleArea(new Point(300, 350), new Point(349, 350), new Point(349, 399)), new TriangleArea(new Point(450, 200), new Point(450, 249), new Point(499, 249))],
            // Rectangle holes
            [],
            // Checkpoints
            [
                new CheckPoint(new Point(463,262), new RectangleArea(new Point(462,232), new Point(518,369)), 0, 12),
                new CheckPoint(new Point(600,180), new RectangleArea(new Point(531,167), new Point(664,223)), 1, 8),
                new CheckPoint(new Point(485,65), new RectangleArea(new Point(470,29), new Point(528,168)), 2, 4),
                new CheckPoint(new Point(365,210), new RectangleArea(new Point(334,190), new Point(463,245)), 3, 0),
                new CheckPoint(new Point(400,385), new RectangleArea(new Point(338,362), new Point(459,417)), 4, 0),
                new CheckPoint(new Point(285,500), new RectangleArea(new Point(271,423), new Point(325,558)), 5, 4),
                new CheckPoint(new Point(165,385), new RectangleArea(new Point(138,359), new Point(268,423)), 6, 8),
                new CheckPoint(new Point(290,260), new RectangleArea(new Point(278,229), new Point(331,362)), 7, 12)
            ],
            // Spawns
            [new Point(434, 300), new Point(406, 285), new Point(378, 270), new Point(350, 253)],
            // Spawn rotation
            12,
            // Speed pads
            [new SpeedPad(310, 261, "Droite"), new SpeedPad(310, 301, "Droite")],
            // Race HTML <img>
            document.querySelector("#race2"),
            // Item boxes
            [
                new ItemBox(new CircleArea(new Point(527 + 11, 103 + 14), 20), document.querySelector("#box0")),
                new ItemBox(new CircleArea(new Point(557 + 11, 73 + 14), 20), document.querySelector("#box1")),
                new ItemBox(new CircleArea(new Point(220 + 11, 415 + 14), 20), document.querySelector("#box2")),
                new ItemBox(new CircleArea(new Point(190 + 11, 445 + 14), 20), document.querySelector("#box3"))
            ],
            3,
            // Left path
            [new Point(497,249),new Point(534,234),new Point(549,199),new Point(533,162),new Point(498,148),new Point(463,163),new Point(448,197),
             new Point(448,395),new Point(404,504),new Point(298,548),new Point(192,503),new Point(149,398),new Point(193,293),new Point(296,249)],
            // Right path
            [new Point(497,348),new Point(604,304),new Point(648,199),new Point(603,92),new Point(498,49),new Point(393,93),new Point(349,197),
             new Point(349,395),new Point(334,434),new Point(298,449),new Point(262,433),new Point(248,398),new Point(263,363),new Point(296,348)],
            // Checkpoint targets
            [1,3,5,7,8,10,12,0],
            // Left is better ?
            [true, true, true, true, true, true, true, false, false, false, false, false, false, false]
        ),
        new Race(
            // Safe circle areas
            [new CircleArea(new Point(200, 260), 100), new CircleArea(new Point(600, 340), 100)],
            // Safe triangle areas
            [],
            // Safe rectangle areas
            [new RectangleArea(new Point(200, 240), new Point(599, 359))],
            // Circle holes
            [new CircleArea(new Point(200, 260), 25), new CircleArea(new Point(600, 340), 25)],
            // Triangle holes
            [],
            // Rectangle holes
            [],
            // Checkpoints
            [
                new CheckPoint(new Point(384,267), new RectangleArea(new Point(383,221), new Point(425,365)), 0, 12),
                new CheckPoint(new Point(580,254), new RectangleArea(new Point(579,217), new Point(621,331)), 1, 12),
                new CheckPoint(new Point(585,390), new RectangleArea(new Point(579,332), new Point(621,450)), 2, 4),
                new CheckPoint(new Point(475,315), new RectangleArea(new Point(475,220), new Point(509,364)), 3, 4),
                new CheckPoint(new Point(290,315), new RectangleArea(new Point(288,220), new Point(325,365)), 4, 4),
                new CheckPoint(new Point(182,312), new RectangleArea(new Point(181,251), new Point(219,369)), 5, 4),
                new CheckPoint(new Point(183,168), new RectangleArea(new Point(182,142), new Point(220,251)), 6, 12)
            ],
            // Spawns
            [new Point(343,266),new Point(343,294),new Point(355,238),new Point(355,322)],
            // Spawn rotation
            12,
            // Speed pads
            [new SpeedPad(287, 252, "Droite"), new SpeedPad(483, 312, "Gauche")],
            // Race HTML <img>
            document.querySelector("#race3"),
            // Item boxes
            [
                new ItemBox(new CircleArea(new Point(209 + 11, 257 + 14), 20), document.querySelector("#box0")),
                new ItemBox(new CircleArea(new Point(544 + 11, 281 + 14), 20), document.querySelector("#box1")),
                new ItemBox(new CircleArea(new Point(115 + 11, 171 + 14), 20), document.querySelector("#box2")),
                new ItemBox(new CircleArea(new Point(633 + 11, 363 + 14), 20), document.querySelector("#box3"))
            ],
            4,
            // Left path
            [new Point(419,240),new Point(599,240),new Point(670,269),new Point(699,339),
             new Point(670,410),new Point(599,439),new Point(529,410),new Point(501,359),
             new Point(380,359),new Point(199,359),new Point(129,330),new Point(100,259),
             new Point(129,189),new Point(199,160),new Point(270,189),new Point(297,240)],
            // Right path
            [new Point(419,359),new Point(599,314),new Point(617,322),new Point(625,339),
             new Point(617,357),new Point(599,365),new Point(582,357),new Point(501,240),
             new Point(380,240),new Point(199,285),new Point(182,277),new Point(174,259),
             new Point(182,242),new Point(199,234),new Point(217,242),new Point(297,359)],
            // Checkpoint targets
            [1,2,7,8,9,11,14],
            // Left is best ?
            [true, false, false, false, false, false, false, true, 
             true, false, false, false, false, false, false, true]
        ),
        new Race(
            // Safe circle areas
            [],
            // Safe triangle areas
            [],
            // Safe rectangle areas
            [
                new RectangleArea(new Point(300, 200), new Point(499, 399))
            ],
            // Circle holes
            [],
            // Triangle holes
            [],
            // Rectangle holes
            [
                new RectangleArea(new Point(378, 278), new Point(421, 321))
            ],
            // Checkpoints
            [
                new CheckPoint(new Point(400, 220), new RectangleArea(new Point(384, 179), new Point(415, 288)), 0, 12),
                new CheckPoint(new Point(400, 360), new RectangleArea(new Point(380, 300), new Point(420, 410)), 1, 4)
            ],
            // Spawns
            [
                new Point(346, 230),
                new Point(358, 201),
                new Point(329, 201),
                new Point(317, 230)
            ],
            // Spawn rotation
            12,
            // Speed pads
            [],
            // Race HTML <img>
            document.querySelector("#race4"),
            // Item boxes
            [
                new ItemBox(new CircleArea(new Point(453 + 11, 190 + 14), 20), document.querySelector("#box0")),
                new ItemBox(new CircleArea(new Point(303 + 11, 343 + 14), 20), document.querySelector("#box1"))
            ],
            9,
            // Left path
            [new Point(414,200),new Point(496,203),new Point(499,300),new Point(496,397),new Point(399,399),
                new Point(303,396),new Point(300,299),new Point(303,203),new Point(385,200)],
            // Right path
            [new Point(414,275),new Point(422,277),new Point(424,300),new Point(421,322),new Point(399,324),
                new Point(377,322),new Point(375,299),new Point(377,277),new Point(385,275)],
            // Checkpoint targets
            [1,5],
            // Left is best ?
            [false, false, false, false, false, false, false, false, false]
        ),
        new Race(
            // Safe circle areas
            [],
            // Safe triangle areas
            [],
            // Safe rectangle areas
            [
                new RectangleArea(new Point(100, 175), new Point(699, 249)),
                new RectangleArea(new Point(100, 175), new Point(199, 424)),
                new RectangleArea(new Point(600, 175), new Point(699, 424)),
                new RectangleArea(new Point(100, 350), new Point(324, 424)),
                new RectangleArea(new Point(475, 350), new Point(699, 424)),
                new RectangleArea(new Point(250, 300), new Point(549, 374)),
            ],
            // Circle holes
            [],
            // Triangle holes
            [],
            // Rectangle holes
            [],
            // Checkpoints
            [
                new CheckPoint(new Point(383, 312), new RectangleArea(new Point(381, 284), new Point(418, 386)), 0, 4),
                new CheckPoint(new Point(118, 359), new RectangleArea(new Point(94, 323), new Point(206, 436)), 1, 8),
                new CheckPoint(new Point(252, 202), new RectangleArea(new Point(240, 156), new Point(283, 253)), 2, 12),
                new CheckPoint(new Point(523, 202), new RectangleArea(new Point(513, 157), new Point(561, 253)), 3, 12),
                new CheckPoint(new Point(654, 375), new RectangleArea(new Point(596, 327), new Point(704, 436)), 4, 4)

            ],
            // Spawns
            [
                new Point(420, 304),
                new Point(435, 330),
                new Point(448, 304),
                new Point(463, 330)
            ],
            // Spawn rotation
            4,
            // Speed pads
            [
                new SpeedPad(211, 379, "Gauche"),
                new SpeedPad(566, 379, "Gauche"),
                new SpeedPad(196, 187, "Droite"),
                new SpeedPad(574, 187, "Droite")
            ],
            // Race HTML <img>
            document.querySelector("#race5"),
            // Item boxes
            [
                new ItemBox(new CircleArea(new Point(119, 286), 20), document.querySelector("#box0")),
                new ItemBox(new CircleArea(new Point(161, 286), 20), document.querySelector("#box1")),
                new ItemBox(new CircleArea(new Point(619, 286), 20), document.querySelector("#box2")),
                new ItemBox(new CircleArea(new Point(661, 286), 20), document.querySelector("#box3")),
                new ItemBox(new CircleArea(new Point(390, 195), 20), document.querySelector("#box4")),
            ],
            3,
            // Left path
            [new Point(380,374),new Point(326,376),new Point(321,421),new Point(103,421),new Point(100,296),new Point(102,177),
                new Point(334,175),new Point(486,175),new Point(696,177),new Point(699,299),new Point(696,421),new Point(478,421),
                new Point(473,376)],
            // Right path
            [new Point(380,300),new Point(253,303),new Point(248,348),new Point(201,348),new Point(199,296),new Point(201,251),
                new Point(334,249),new Point(486,249),new Point(597,251),new Point(600,299),new Point(598,348),new Point(551,348),
                new Point(546,303)],
            // Checkpoint targets
            [1,5,7,8,11],
            // Left is best ?
            [true, true, false, false, false, false, false, false, false, false, false, false, true]
        )
    ];

}

function createPlayers(n){
    zPlayers = [
        new PlayerData(new KeyControls("ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown"), gJoueurs[0], gOmbres[0], 1),
        n > 1 ? 
            new PlayerData(new KeyControls("a", "d", "w", "s"), gJoueurs[1], gOmbres[1], 2) :
            new Cpu(new KeyControls("a", "d", "w", "s"), gJoueurs[1], gOmbres[1], 2, gDifficulte),
        n > 2 ? 
            new PlayerData(new KeyControls("j", "l", "i", "k"), gJoueurs[2], gOmbres[2], 3) :
            new Cpu(new KeyControls("j", "l", "i", "k"), gJoueurs[2], gOmbres[2], 3, gDifficulte),
        n > 3 ? 
            new PlayerData(new KeyControls("4", "6", "8", "5"), gJoueurs[3], gOmbres[3], 4) :
            new Cpu(new KeyControls("4", "6", "8", "5"), gJoueurs[3], gOmbres[3], 4, gDifficulte)
    ];
}

function hideBoxes(){
    let boxes = zRaces[zRaceChoice].boxes;
    for(let i = boxes.length; i < 6; i++){
        document.querySelector("#box" + i).style.display = "none";
        document.querySelector("#box" + i).style.left = "0px";
        document.querySelector("#box" + i).style.ltop = "0px";
    }
}

function dist2(v, w) { return Math.pow(v.x - w.x, 2) + Math.pow(v.y - w.y, 2) }
function distToSegmentSquared(p, v, w) {
  var l2 = dist2(v, w);
  if (l2 == 0) return dist2(p, v);
  var t = ((p.x - v.x) * (w.x - v.x) + (p.y - v.y) * (w.y - v.y)) / l2;
  t = Math.max(0, Math.min(1, t));
  return dist2(p, { x: v.x + t * (w.x - v.x),
                    y: v.y + t * (w.y - v.y) });
}

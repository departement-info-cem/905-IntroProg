// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
//                            Variables globales
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
let gCartesHTML = []; // Contiendra les 20 éléments HTML avec la classe .carte

// Contient les 10 paires de noms d'images existantes.
let gListeImages = ["bombe", "bombe", "moai", "moai", "peche", "peche",
    "aubergine", "aubergine", "seringue", "seringue", "colere", "colere",
    "crottin", "crottin", "pillule", "pillule", "ufo", "ufo", "rire", "rire"];

let gPairesRestantes = 10; // Nombre de paires qu'il reste à découvrir
let gNbErreurs = 0; // Nombre de tentatives échouées depuis le début de la partie

let gJeuEnCours = false; // Détermine quand l'utilisateur peut cliquer sur les cartes

let gDeuxiemeTour = false; // Sommes-nous en train de révéler une 2e carte ?
let gCarte1 = null; // Première carte HTML cliquée lors d'une tentative
let gCarte2 = null; // Deuxième carte HTML cliquée lors d'une tentative

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
//                              Initialisation
//
// - Créer 20 <img class="carte" src="images/carte.png" alt="carte"> 
//   pour les cartes. Cliquer sur chaque carte appelle choisirCarte(). De plus,
//   chacun de ces 20 éléments <img> devra être ajouté dans le tableau gCartesHTML.
//   Les 20 éléments devront être placés dans l'élément .row existant.
// - Le bouton pour jouer doit être cliquable. (La fonction à appeler n'existe pas encore)
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
function init(){



}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
//                         Fonctions (Section guidée)
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

// Retourne un nombre entier aléatoire entre 0 et max (inclus)
function nombreAleatoireEntre0EtMax(max){


    
}

// Choisit une image aléatoire pour chacune des 20 cartes et réinitialise
// toutes les cartes pour préparer une nouvelle partie.
function remplirCartesAleatoirement(){



}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
//                         Fonctions (Section libre)
//
// N'oubliez pas de commenter chacune de vos fonctions. (Français évalué)
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀





// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
//                     Code déjà complété (NE PAS MODIFIER)
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

// Remet les 10 paires de noms d'images dans le tableau gListeImages.
function reinitialiserListeNoms(){

    gListeImages = ["bombe", "bombe", "moai", "moai", "peche", "peche",
    "aubergine", "aubergine", "seringue", "seringue", "colere", "colere",
    "crottin", "crottin", "pillule", "pillule", "ufo", "ufo", "rire", "rire"];

}

// Écouteurs d'événements (Rien à ajouter)
function init(){

    document.querySelector(".bouton1").addEventListener("click", mitaines);
    document.querySelector(".bouton2").addEventListener("click", bananes);
    document.querySelector(".bouton3").addEventListener("click", mystere);

}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 1 : Compléter mitaines()
//
// - On déclare une variable locale nommée elementsJV qui contient un tableau
//   avec tous les éléments possédant la classe ".jv".
// - À l'aide d'une boucle, on remplace le contenu textuel de tous ces éléments
//   par "mitaines".
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function mitaines(){


}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 2 : Compléter bananes()
//
// - Pour tous les éléments possédant la classe ".fruit", si l'attribut "alt" est
//   "aubergine", on modifie la valeur de l'attribut "src" pour 
//   "images/banane.png".
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function bananes(){


    
}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 3 : Compléter mystere()
//
// - On déclare une variable locale nommée texteAlerte et on lui affecte une
//   chaîne de caractères vide. (Donc "")
// - À l'aide d'une boucle, on doit AJOUTER le contenu textuel de tous les éléments
//   possédant la classe ".secret" dans la variable texteAlerte. (Ce qui créera donc,
//   progressivement, une phrase secrète composée du contenu textuel de tous ces
//   éléments)
// - Finalement, on lance une alerte avec le texte dans la variable texteAlerte.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function mystere(){


    
}
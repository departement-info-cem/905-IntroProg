// █▀▀▀▀▀▀▀▀▀█
// █ Étape 3 █
// █▄▄▄▄▄▄▄▄▄█

function mystere1(){

    console.log("Poire 🍐");
    
}

function mystere2(){

    document.querySelector(".rouge").textContent = "Poire 🍐";
    
}

function mystere3(){

    document.querySelector(".potassium").textContent = " Raisin 🍇";
    
}

function mystere4(){

    alert("Poire 🍐");
    
}

function mystere5(){

    document.querySelector(".humm").textContent += " Raisin 🍇";
    
}



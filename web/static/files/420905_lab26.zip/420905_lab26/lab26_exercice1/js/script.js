// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 1 : Rendre la page fonctionnelle
//
// 💡 Indices 💡
// Vous devriez vous en sortir avec :
// - 4 écouteurs d'événements
// - 2+ variables globales
// - 4+ fonctions supplémentaires
//
// Si des aspects sont flous, commencez par ce qui est plus simple !
//    - Rendre le premier compteur fonctionnel.
//    - Rendre le deuxième compteur fonctionnel.
//    - Changer la valeur du troisième compteur lorsque nécessaire. 
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

// Variables globales


// Écouteurs d'événements
function init(){



}



// Rien à changer dans init() !
function init(){

    document.addEventListener("keydown", toucheClavier);
    document.querySelector(".bouton1").addEventListener("click", compterNbMots);
    document.querySelector(".bouton2").addEventListener("click", function(){ changerTexte("Texte avec quatre mots.") });
    document.querySelector(".bouton3").addEventListener("click", function(){ changerTexte(` Texte, avec  quatre   mots. `) });

}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 1 : Compléter compterNbMots()
//
// - Récupérez le contenu textuel de l'élément .texte, puis affichez, dans
//   la console, le nombre de mots de ce texte.
//
// (Un mot est n'importe quel caractère ou groupe de caractères qui n'est pas
//  une espace. Exemple : " allo  bye   hum  ", c'est 3 mots.)
//
// 💡 Indices 💡
// - Vous aurez entres autres besoin d'une boucle et de .charAt()
// - Pas besoin de variables globales, pas besoin de fonction supplémentaires.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function compterNbMots(){



}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// Ne pas toucher au code à partir d'ici
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
function toucheClavier(e){
    if(e.key == " " || e.key == "'"){
        e.preventDefault();
    }
    if(e.key.length == 1 && e.key.match("[a-ùA-Ù]|[.,']")){
        document.querySelector(".texte").textContent += e.key;
    }
    if(e.key == "Backspace"){
        document.querySelector(".texte").textContent = 
        document.querySelector(".texte").textContent.substring(0, 
            document.querySelector(".texte").textContent.length - 1)
    }
}

function changerTexte(texte){

    document.querySelector(".texte").textContent = texte;

}
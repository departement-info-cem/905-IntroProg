// Variables globales
let gCompteur = 0;

// Écouteurs d'événements (INTERDIT DE MODIFIER !)
function init(){

   document.querySelector(".up1").addEventListener("click", augmenter);
   document.querySelector(".up2").addEventListener("click", augmenter);

   document.querySelector(".down1").addEventListener("click", reduire);
   document.querySelector(".down2").addEventListener("click", reduire);

}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 1 : Créer les fonctions augmenter() et reduire().
//
// - La fonction augmenter() augmente la valeur du compteur de 1 ou 2, en
//   appelant la fonction modifierCompteur, qui est déjà codée.
// - Si l'élément cliqué possède la classe "super", on  augmente la 
//   valeur du compteur de 2, sinon de 1.
// - De plus, si la valeur du compteur est plus grande ou égale à 10, le
//   texte devient de couleur rouge.
//
// - Pour la fonction reduire(), on fait la même chose, mais en réduisant
//   la valeur de 1 ou de 2 et en remettant le texte en noir si la valeur
//   redevient inférieure à 10.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

// Vous êtes obligés d'utiliser cette fonction. Le paramètre valeur doit être
// -2, -1, 1 ou 2 lorsque  vous appelez la fonction. La fonction va modifier
// le compteur et son affichage dans la page pour vous !
// Normalement, vous devriez l'appeler 4 fois. (Pour +2, +1, -1 et -2)
function modifierCompteur(valeur){

    // Ne pas modifier ces deux lignes
    gCompteur += valeur;
    document.querySelector(".compteur").textContent = `Valeur : ${gCompteur}`;

    // Vous pouvez ajouter du code ici si vous voulez (Pas forcément obligé)

}


// Variables globales
let gSections = [false, false, false]; // Lorsqu'une section est affichée, on pourrait mettre un true dans ce tableau

// Écouteurs d'événements
function init(){

    let barres = document.querySelectorAll(".barre");

    for(let i = 0; i < barres.length; i += 1){

        // Chaque barre est cliquable et appelle affichageSection() avec l'index 0, 1 ou 2
        barres[i].addEventListener("click", function(){ affichageSection(i) });

    }

}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 1 : Compléter affichageSection()
//
// Quand on clique sur une .barre, sa .section doit s'afficher ou se cacher.
// Voici les propriétés à éditer :
// 
//   Propriété   |  Cachée  |   Affichée    |
//  ═════════════╪══════════╪═══════════════╡
//   height      |  "0px"   | "fit-content" |
//   borderWidth |  "0px"   |     "1px"     |
//   padding     |"0px 10px"|    "10px"     |
//
// De plus, lorsqu'une .section est affichée, la flèche au-dessus doit être
// 🔼 plutôt que 🔽. (C'est du textContent)
//
// N'oubliez pas lorsqu'on déplie une .section, on doit cacher les autres 
// si elles étaient affichées !
//
// ⛔ Interdit de modifier le HTML et le CSS.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function affichageSection(index){



}
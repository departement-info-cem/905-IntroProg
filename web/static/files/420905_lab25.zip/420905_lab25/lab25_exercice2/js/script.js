
// Écouteurs d'événements
function init(){

    for(let i = 1; i < 4; i += 1){
        // Chaque onglet et cliquable et appelle afficherOnglet() avec la valeur 1, 2 ou 3
        document.querySelector(".onglet" + i).addEventListener("click", function(){ afficherOnglet(i) });
    }

}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 1 : Compléter afficherOnglet()
//
// Quand on clique sur un onglet, son contenu doit s'afficher et les deux
// autres doivent être cachés.
//
// Voici les propriétés à éditer pour les titres d'onglet :
// 
//     Propriété    |  Inactif |     Actif     |
//  ════════════════╪══════════╪═══════════════╡
//   textDecoration |  "none"  |  "underline"  |
//   fontWeight     | "normal" |    "bold"     |
//
// De plus, il faudra jouer avec la propriété display du contenu.
//
// ⛔ Interdit de modifier le HTML et le CSS.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function afficherOnglet(index){



}

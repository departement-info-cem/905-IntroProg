// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 1 : Tout coder
//
// Il n'y a que deux éléments importants : .bouton1 et .tooltip
//
// Voici le comportement souhaité :
//
// • Survoler .bouton1 met l'opacité de .tooltip à 100%
// • Arrêter de survoler .bouton met l'opacité de .tooltip à 0%
//
// • On peut verrouiller l'opacité de .tooltip à 100% en cliquant sur .bouton1
// • Si on clique à nouveau sur .bouton1, cela déverrouille l'opacité de
//   .tooltip, qui redevient sensible au survol / non-survol du bouton.
//
// ⛔ Interdit de modifier le HTML et le CSS. (Vous pouvez les consulter
//     si vous voulez, mais ce n'est pas essentiel du tout)
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀


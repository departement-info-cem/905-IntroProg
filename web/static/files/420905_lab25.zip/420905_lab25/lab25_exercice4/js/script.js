
// Rien à changer dans init() !
function init(){

    // deplacerEmoji() sera appelée toutes les 25 millisecondes. Autrement dit, 40 fois par seconde.
    setInterval(deplacerEmoji, 25);

}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 1 : Compléter deplacerEmoji()
//
// - N'hésitez pas à ajouter une ou des variables globales !
// - Pour déplacer l'émoji, utilisez le style left. Ce style contient une
//   valeur avec le format "350px" par exemple. 
// - N'oubliez pas que vous pouvez convertir la chaîne de caractères "350px"
//   en nombre 350 grâce à parseInt().
// - La boîte fait 800 pixels de large. Le smiley fait 43 pixels de large.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
function deplacerEmoji(){



}